import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:flutter_map_cancellable_tile_provider/flutter_map_cancellable_tile_provider.dart';
import 'package:latlong2/latlong.dart';
import 'package:provider/provider.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../providers/order_provider.dart';
import '../../providers/auth_provider.dart';
import '../../models/order_model.dart';
import '../../config/app_config.dart';
import '../../core/theme/app_theme.dart';
import '../../localization/app_localizations.dart';
import '../../routes/app_routes.dart';

/// شاشة تتبع الطلب - عرض حالة الطلب وموقع السائق لحظياً
class OrderTrackingScreen extends StatefulWidget {
  final String orderId;
  const OrderTrackingScreen({super.key, required this.orderId});

  @override
  State<OrderTrackingScreen> createState() => _OrderTrackingScreenState();
}

class _OrderTrackingScreenState extends State<OrderTrackingScreen> {
  final MapController _mapController = MapController();
  LatLng? _driverLocation;

  @override
  void initState() {
    super.initState();
    _listenDriverLocation();
  }

  void _listenDriverLocation() {
    // سيتم تحديث الموقع في build عبر تدفق المستخدم
  }

  Future<void> _showRatingDialog(OrderModel order) async {
    double rating = 5;
    final reviewCtrl = TextEditingController();
    final t = AppLocalizations.of(context)!;
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(t.t('rate_driver')),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            RatingBar.builder(
              initialRating: 5,
              minRating: 1,
              allowHalfRating: true,
              itemCount: 5,
              itemBuilder: (_, __) =>
                  const Icon(Icons.star, color: Colors.amber),
              onRatingUpdate: (r) => rating = r,
            ),
            const SizedBox(height: 12),
            TextField(
              controller: reviewCtrl,
              decoration: InputDecoration(labelText: t.t('review')),
              maxLines: 2,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(t.t('cancel')),
          ),
          ElevatedButton(
            onPressed: () async {
              await context.read<OrderProvider>().rateOrder(
                    orderId: order.id,
                    driverId: order.driverId!,
                    rating: rating,
                    review: reviewCtrl.text.trim(),
                  );
              if (context.mounted) Navigator.pop(context);
            },
            child: Text(t.t('save')),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    return Scaffold(
      appBar: AppBar(title: Text(t.t('order_status'))),
      body: StreamBuilder<OrderModel?>(
        stream: context.read<OrderProvider>().watchOrder(widget.orderId),
        builder: (context, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final order = snap.data!;
          final routePoints = order.routeCoordinates
                  ?.map((c) => LatLng(c[0], c[1]))
                  .toList() ??
              [
                LatLng(order.pickupLat, order.pickupLng),
                LatLng(order.destinationLat, order.destinationLng),
              ];

          return Column(
            children: [
              Expanded(
                flex: 2,
                child: FlutterMap(
                  mapController: _mapController,
                  options: MapOptions(
                    initialCenter:
                        LatLng(order.pickupLat, order.pickupLng),
                    initialZoom: 13,
                  ),
                  children: [
                    TileLayer(
                      urlTemplate: AppConfig.osmTileUrl,
                      userAgentPackageName: 'com.wasl.talabi',
                      tileProvider: CancellableNetworkTileProvider(),
                    ),
                    PolylineLayer(
                      polylines: [
                        Polyline(
                          points: routePoints,
                          strokeWidth: 4,
                          color: AppColors.primary,
                        ),
                      ],
                    ),
                    MarkerLayer(
                      markers: [
                        Marker(
                          point: LatLng(order.pickupLat, order.pickupLng),
                          width: 50,
                          height: 50,
                          child: const Icon(Icons.location_on,
                              color: AppColors.success, size: 40),
                        ),
                        Marker(
                          point: LatLng(
                              order.destinationLat, order.destinationLng),
                          width: 50,
                          height: 50,
                          child: const Icon(Icons.location_on,
                              color: AppColors.error, size: 40),
                        ),
                        if (order.driverId != null)
                          _DriverMarker(driverId: order.driverId!),
                      ],
                    ),
                  ],
                ),
              ),
              Expanded(
                flex: 2,
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _statusBadge(order.status, t),
                      const SizedBox(height: 16),
                      _infoRow(Icons.straighten, t.t('distance'),
                          '${order.distanceKm.toStringAsFixed(2)} ${t.t('km')}'),
                      _infoRow(Icons.attach_money, t.t('total_price'),
                          '${order.totalPrice.toStringAsFixed(0)} ${t.t('iqd')}'),
                      _infoRow(Icons.local_shipping, t.t('vehicle_type'),
                          order.vehicleNameAr),
                      if (order.driverName != null) ...[
                        const Divider(),
                        _infoRow(Icons.person, 'السائق', order.driverName!),
                        _infoRow(Icons.phone, t.t('phone'),
                            order.driverPhone ?? ''),
                      ],
                      const SizedBox(height: 12),
                      if (order.driverId != null &&
                          order.status != 'cancelled' &&
                          order.status != 'delivered')
                        Row(
                          children: [
                            Expanded(
                              child: ElevatedButton.icon(
                                onPressed: () => Navigator.pushNamed(
                                  context,
                                  AppRoutes.chat,
                                  arguments: {
                                    'orderId': order.id,
                                    'otherUserName': order.driverName,
                                  },
                                ),
                                icon: const Icon(Icons.chat),
                                label: Text(t.t('chat')),
                              ),
                            ),
                          ],
                        ),
                      const SizedBox(height: 8),
                      if (order.status == 'delivered' &&
                          order.customerRating == null)
                        ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.amber),
                          icon: const Icon(Icons.star),
                          label: Text(t.t('rate_driver')),
                          onPressed: () => _showRatingDialog(order),
                        ),
                      if (order.status == 'pending')
                        ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                              backgroundColor: AppColors.error),
                          icon: const Icon(Icons.cancel),
                          label: Text(t.t('cancel_order')),
                          onPressed: () async {
                            await context
                                .read<OrderProvider>()
                                .cancelOrder(order.id, 'إلغاء من العميل');
                            if (context.mounted) Navigator.pop(context);
                          },
                        ),
                    ],
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _statusBadge(String status, AppLocalizations t) {
    Color color = AppColors.warning;
    IconData icon = Icons.hourglass_empty;
    String label = t.t(status);
    switch (status) {
      case 'accepted':
        color = AppColors.primary;
        icon = Icons.check_circle;
        break;
      case 'picked_up':
      case 'in_transit':
        color = AppColors.primary;
        icon = Icons.local_shipping;
        break;
      case 'delivered':
        color = AppColors.success;
        icon = Icons.done_all;
        break;
      case 'cancelled':
        color = AppColors.error;
        icon = Icons.cancel;
        break;
    }
    return Card(
      color: color.withOpacity(0.1),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Icon(icon, color: color, size: 32),
            const SizedBox(width: 12),
            Text(label,
                style: TextStyle(
                    color: color,
                    fontSize: 18,
                    fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }

  Widget _infoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Icon(icon, color: AppColors.primary),
          const SizedBox(width: 12),
          Text(label, style: const TextStyle(color: Colors.grey)),
          const Spacer(),
          Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}

/// علامة موقع السائق المباشرة على الخريطة
class _DriverMarker extends Marker {
  _DriverMarker({required String driverId})
      : super(
          point: const LatLng(0, 0),
          width: 50,
          height: 50,
          child: _DriverIcon(driverId: driverId),
        );
}

class _DriverIcon extends StatelessWidget {
  final String driverId;
  const _DriverIcon({required this.driverId});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: FirebaseFirestore.instance
          .collection('users')
          .doc(driverId)
          .snapshots(),
      builder: (_, snap) {
        return const Icon(Icons.directions_car,
            color: Colors.blue, size: 36);
      },
    );
  }
}
