import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../providers/order_provider.dart';
import '../../models/order_model.dart';
import '../../core/theme/app_theme.dart';
import '../../localization/app_localizations.dart';
import '../../routes/app_routes.dart';
import '../../widgets/order_card.dart';

class CustomerHomeScreen extends StatefulWidget {
  const CustomerHomeScreen({super.key});

  @override
  State<CustomerHomeScreen> createState() => _CustomerHomeScreenState();
}

class _CustomerHomeScreenState extends State<CustomerHomeScreen> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    final user = context.watch<AuthProvider>().currentUser!;

    final pages = [
      _buildHomeTab(t),
      _buildOrdersTab(user.uid),
      const _ProfileTab(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text(t.t('app_name')),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () => Navigator.pushNamed(context, AppRoutes.settings),
          ),
        ],
      ),
      body: pages[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (i) => setState(() => _currentIndex = i),
        items: [
          BottomNavigationBarItem(
              icon: const Icon(Icons.home), label: t.t('home')),
          BottomNavigationBarItem(
              icon: const Icon(Icons.list_alt), label: t.t('orders')),
          BottomNavigationBarItem(
              icon: const Icon(Icons.person), label: t.t('profile')),
        ],
      ),
      floatingActionButton: _currentIndex == 0
          ? FloatingActionButton.extended(
              onPressed: () =>
                  Navigator.pushNamed(context, AppRoutes.createOrder),
              icon: const Icon(Icons.add_location_alt),
              label: Text(t.t('create_order')),
              backgroundColor: AppColors.secondary,
            )
          : null,
    );
  }

  Widget _buildHomeTab(AppLocalizations t) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Card(
            color: AppColors.primary,
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.local_shipping,
                      color: Colors.white, size: 40),
                  const SizedBox(height: 12),
                  Text(
                    t.t('welcome'),
                    style: const TextStyle(
                        color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'احجز توصيل بضائعك بسهولة وأمان',
                    style: TextStyle(color: Colors.white70),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          Text(
            t.t('select_vehicle'),
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 3,
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 0.9,
            children: [
              _vehicleCard(Icons.electric_rickshaw, t.t('stuta')),
              _vehicleCard(Icons.electric_rickshaw, t.t('tuktuk')),
              _vehicleCard(Icons.local_shipping, t.t('pickup')),
              _vehicleCard(Icons.fire_truck, t.t('ton_1')),
              _vehicleCard(Icons.fire_truck, t.t('ton_3')),
              _vehicleCard(Icons.fire_truck, t.t('ton_5')),
            ],
          ),
        ],
      ),
    );
  }

  Widget _vehicleCard(IconData icon, String name) {
    return Card(
      child: InkWell(
        onTap: () => Navigator.pushNamed(context, AppRoutes.createOrder),
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 40, color: AppColors.primary),
              const SizedBox(height: 8),
              Text(name, textAlign: TextAlign.center,
                  style: const TextStyle(fontWeight: FontWeight.bold)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildOrdersTab(String userId) {
    return StreamBuilder<List<OrderModel>>(
      stream: context.read<OrderProvider>().getCustomerOrders(userId),
      builder: (context, snap) {
        if (!snap.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        final orders = snap.data!;
        if (orders.isEmpty) {
          return const Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.inbox, size: 80, color: Colors.grey),
                SizedBox(height: 12),
                Text('لا توجد طلبات بعد'),
              ],
            ),
          );
        }
        return ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: orders.length,
          itemBuilder: (_, i) => OrderCard(
            order: orders[i],
            onTap: () => Navigator.pushNamed(
              context,
              AppRoutes.orderTracking,
              arguments: orders[i].id,
            ),
          ),
        );
      },
    );
  }
}

class _ProfileTab extends StatelessWidget {
  const _ProfileTab();
  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthProvider>().currentUser!;
    final t = AppLocalizations.of(context)!;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Center(
          child: CircleAvatar(
            radius: 50,
            backgroundColor: AppColors.primary,
            child: Text(
              user.name.isNotEmpty ? user.name[0].toUpperCase() : '?',
              style: const TextStyle(fontSize: 36, color: Colors.white),
            ),
          ),
        ),
        const SizedBox(height: 16),
        Center(child: Text(user.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
        Center(child: Text(user.email, style: const TextStyle(color: Colors.grey))),
        const SizedBox(height: 24),
        ListTile(
          leading: const Icon(Icons.phone),
          title: Text(t.t('phone')),
          subtitle: Text(user.phone),
        ),
        ListTile(
          leading: const Icon(Icons.settings),
          title: Text(t.t('settings')),
          onTap: () => Navigator.pushNamed(context, AppRoutes.settings),
        ),
        const SizedBox(height: 12),
        ElevatedButton.icon(
          style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
          icon: const Icon(Icons.logout),
          label: Text(t.t('logout')),
          onPressed: () async {
            await context.read<AuthProvider>().logout();
            if (context.mounted) {
              Navigator.pushNamedAndRemoveUntil(
                  context, AppRoutes.login, (_) => false);
            }
          },
        ),
      ],
    );
  }
}
