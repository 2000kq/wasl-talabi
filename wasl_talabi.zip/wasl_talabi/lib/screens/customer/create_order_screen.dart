import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:flutter_map_cancellable_tile_provider/flutter_map_cancellable_tile_provider.dart';
import 'package:latlong2/latlong.dart';
import 'package:provider/provider.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '../../providers/auth_provider.dart';
import '../../providers/order_provider.dart';
import '../../config/app_config.dart';
import '../../core/services/location_service.dart';
import '../../core/services/osrm_service.dart';
import '../../core/theme/app_theme.dart';
import '../../core/constants/app_constants.dart';
import '../../localization/app_localizations.dart';
import '../../routes/app_routes.dart';

/// شاشة إنشاء الطلب - تحديد موقع الاستلام والتسليم ونوع المركبة
class CreateOrderScreen extends StatefulWidget {
  const CreateOrderScreen({super.key});

  @override
  State<CreateOrderScreen> createState() => _CreateOrderScreenState();
}

class _CreateOrderScreenState extends State<CreateOrderScreen> {
  final MapController _mapController = MapController();
  LatLng? _pickup;
  LatLng? _destination;
  String _pickupAddress = '';
  String _destinationAddress = '';
  String _selectingMode = 'pickup'; // pickup | destination
  String _selectedVehicleId = 'stuta';
  final _notesCtrl = TextEditingController();
  double? _distanceKm;
  double? _totalPrice;
  List<LatLng> _routePoints = [];
  bool _isCalculating = false;

  @override
  void initState() {
    super.initState();
    _initLocation();
  }

  Future<void> _initLocation() async {
    final loc = await LocationService.getCurrentLocation();
    if (loc != null && mounted) {
      _mapController.move(loc, 15);
    }
  }

  void _onMapTap(LatLng point) async {
    setState(() {
      if (_selectingMode == 'pickup') {
        _pickup = point;
      } else {
        _destination = point;
      }
    });
    final addr = await OSRMService.reverseGeocode(point);
    if (!mounted) return;
    setState(() {
      if (_selectingMode == 'pickup') {
        _pickupAddress = addr ?? 'موقع محدد';
      } else {
        _destinationAddress = addr ?? 'موقع محدد';
      }
    });
    if (_pickup != null && _destination != null) {
      _calculateRoute();
    }
  }

  Future<void> _calculateRoute() async {
    setState(() => _isCalculating = true);
    final vehicle = AppConstants.vehicleTypes
        .firstWhere((v) => v['id'] == _selectedVehicleId);
    final pricePerKm = (vehicle['default_price_per_km'] as num).toDouble();

    final route = await OSRMService.getRoute(start: _pickup!, end: _destination!);
    if (route != null) {
      _distanceKm = route['distance'] as double;
      _routePoints = (route['coordinates'] as List)
          .map<LatLng>((c) => LatLng(c[0] as double, c[1] as double))
          .toList();
    } else {
      _distanceKm = OSRMService.calculateDistance(_pickup!, _destination!);
      _routePoints = [_pickup!, _destination!];
    }
    if (_distanceKm! < AppConfig.minimumDistanceKm) {
      _distanceKm = AppConfig.minimumDistanceKm;
    }
    _totalPrice = _distanceKm! * pricePerKm;
    setState(() => _isCalculating = false);
  }

  Future<void> _submitOrder() async {
    if (_pickup == null || _destination == null) {
      Fluttertoast.showToast(msg: 'حدد موقع الاستلام والتسليم');
      return;
    }
    final user = context.read<AuthProvider>().currentUser!;
    final vehicle = AppConstants.vehicleTypes
        .firstWhere((v) => v['id'] == _selectedVehicleId);

    final order = await context.read<OrderProvider>().createOrder(
          customerId: user.uid,
          customerName: user.name,
          customerPhone: user.phone,
          vehicleType: _selectedVehicleId,
          vehicleNameAr: vehicle['name_ar'],
          pickup: _pickup!,
          pickupAddress: _pickupAddress,
          destination: _destination!,
          destinationAddress: _destinationAddress,
          pricePerKm: (vehicle['default_price_per_km'] as num).toDouble(),
          notes: _notesCtrl.text.trim(),
        );

    if (!mounted) return;
    if (order != null) {
      Fluttertoast.showToast(
        msg: 'تم إنشاء الطلب بنجاح',
        backgroundColor: AppColors.success,
      );
      Navigator.pushReplacementNamed(
        context,
        AppRoutes.orderTracking,
        arguments: order.id,
      );
    } else {
      Fluttertoast.showToast(msg: 'فشل إنشاء الطلب', backgroundColor: AppColors.error);
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    return Scaffold(
      appBar: AppBar(title: Text(t.t('create_order'))),
      body: Column(
        children: [
          // الخريطة OpenStreetMap
          Expanded(
            flex: 3,
            child: Stack(
              children: [
                FlutterMap(
                  mapController: _mapController,
                  options: MapOptions(
                    initialCenter: LatLng(
                        AppConfig.defaultLatitude, AppConfig.defaultLongitude),
                    initialZoom: AppConfig.defaultZoom,
                    onTap: (_, p) => _onMapTap(p),
                  ),
                  children: [
                    TileLayer(
                      urlTemplate: AppConfig.osmTileUrl,
                      userAgentPackageName: 'com.wasl.talabi',
                      tileProvider: CancellableNetworkTileProvider(),
                    ),
                    if (_routePoints.isNotEmpty)
                      PolylineLayer(
                        polylines: [
                          Polyline(
                            points: _routePoints,
                            strokeWidth: 4,
                            color: AppColors.primary,
                          ),
                        ],
                      ),
                    MarkerLayer(
                      markers: [
                        if (_pickup != null)
                          Marker(
                            point: _pickup!,
                            width: 50,
                            height: 50,
                            child: const Icon(Icons.location_on,
                                color: AppColors.success, size: 40),
                          ),
                        if (_destination != null)
                          Marker(
                            point: _destination!,
                            width: 50,
                            height: 50,
                            child: const Icon(Icons.location_on,
                                color: AppColors.error, size: 40),
                          ),
                      ],
                    ),
                  ],
                ),
                Positioned(
                  top: 12,
                  left: 12,
                  right: 12,
                  child: Card(
                    child: Padding(
                      padding: const EdgeInsets.all(8),
                      child: Row(
                        children: [
                          Expanded(
                            child: ChoiceChip(
                              label: Text(t.t('pickup_location')),
                              selected: _selectingMode == 'pickup',
                              onSelected: (_) =>
                                  setState(() => _selectingMode = 'pickup'),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: ChoiceChip(
                              label: Text(t.t('destination_location')),
                              selected: _selectingMode == 'destination',
                              onSelected: (_) => setState(
                                  () => _selectingMode = 'destination'),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Positioned(
                  bottom: 12,
                  right: 12,
                  child: FloatingActionButton(
                    mini: true,
                    onPressed: _initLocation,
                    child: const Icon(Icons.my_location),
                  ),
                ),
              ],
            ),
          ),
          // معلومات الطلب
          Expanded(
            flex: 2,
            child: Container(
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(20),
                  topRight: Radius.circular(20),
                ),
                boxShadow: [
                  BoxShadow(color: Colors.black12, blurRadius: 10),
                ],
              ),
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(t.t('select_vehicle'),
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    SizedBox(
                      height: 90,
                      child: ListView.separated(
                        scrollDirection: Axis.horizontal,
                        itemCount: AppConstants.vehicleTypes.length,
                        separatorBuilder: (_, __) => const SizedBox(width: 8),
                        itemBuilder: (_, i) {
                          final v = AppConstants.vehicleTypes[i];
                          final selected = v['id'] == _selectedVehicleId;
                          return GestureDetector(
                            onTap: () {
                              setState(() => _selectedVehicleId = v['id']);
                              if (_pickup != null && _destination != null) {
                                _calculateRoute();
                              }
                            },
                            child: Container(
                              width: 100,
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                color: selected
                                    ? AppColors.primary
                                    : Colors.grey.shade100,
                                borderRadius: BorderRadius.circular(12),
                                border: Border.all(
                                  color: selected
                                      ? AppColors.primary
                                      : Colors.grey.shade300,
                                ),
                              ),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(Icons.local_shipping,
                                      color: selected
                                          ? Colors.white
                                          : AppColors.primary),
                                  const SizedBox(height: 4),
                                  Text(
                                    v['name_ar'],
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: selected
                                          ? Colors.white
                                          : Colors.black,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                    const SizedBox(height: 12),
                    if (_distanceKm != null)
                      Card(
                        color: AppColors.primary.withOpacity(0.05),
                        child: Padding(
                          padding: const EdgeInsets.all(12),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              Column(children: [
                                Text(t.t('distance'),
                                    style: const TextStyle(color: Colors.grey)),
                                Text('${_distanceKm!.toStringAsFixed(2)} ${t.t('km')}',
                                    style: const TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold)),
                              ]),
                              Column(children: [
                                Text(t.t('total_price'),
                                    style: const TextStyle(color: Colors.grey)),
                                Text(
                                  '${_totalPrice!.toStringAsFixed(0)} ${t.t('iqd')}',
                                  style: const TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      color: AppColors.success),
                                ),
                              ]),
                            ],
                          ),
                        ),
                      ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: _notesCtrl,
                      decoration: InputDecoration(
                        labelText: t.t('notes'),
                        prefixIcon: const Icon(Icons.notes),
                      ),
                      maxLines: 2,
                    ),
                    const SizedBox(height: 12),
                    ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.success,
                      ),
                      icon: _isCalculating
                          ? const SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(
                                  color: Colors.white, strokeWidth: 2),
                            )
                          : const Icon(Icons.check_circle),
                      label: Text(t.t('submit_order')),
                      onPressed: _isCalculating ? null : _submitOrder,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
