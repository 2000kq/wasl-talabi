import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '../../providers/auth_provider.dart';
import '../../core/services/telegram_service.dart';
import '../../localization/app_localizations.dart';
import '../../core/theme/app_theme.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabCtrl;
  final _emailCtrl = TextEditingController();
  final _telegramCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
  }

  Future<void> _sendEmailReset() async {
    final auth = context.read<AuthProvider>();
    final ok = await auth.resetPasswordByEmail(_emailCtrl.text.trim());
    if (!mounted) return;
    Fluttertoast.showToast(
      msg: ok ? 'تم إرسال رابط الاستعادة' : 'فشل الإرسال',
      backgroundColor: ok ? AppColors.success : AppColors.error,
    );
  }

  Future<void> _telegramRecovery() async {
    // فتح بوت Telegram - الباقي يتم في Cloud Function
    final url = TelegramService.getBotDeepLink(startParam: 'reset');
    if (await canLaunchUrl(Uri.parse(url))) {
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    } else {
      Fluttertoast.showToast(msg: 'لا يمكن فتح Telegram');
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    return Scaffold(
      appBar: AppBar(
        title: Text(t.t('forgot_password')),
        bottom: TabBar(
          controller: _tabCtrl,
          labelColor: Colors.white,
          tabs: [
            Tab(text: t.t('email_recovery')),
            Tab(text: t.t('telegram_recovery')),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabCtrl,
        children: [
          // استعادة عبر البريد
          Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                const Icon(Icons.email, size: 80, color: AppColors.primary),
                const SizedBox(height: 24),
                TextField(
                  controller: _emailCtrl,
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(
                    labelText: t.t('email'),
                    prefixIcon: const Icon(Icons.email_outlined),
                  ),
                ),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _sendEmailReset,
                    child: Text(t.t('send_reset_link')),
                  ),
                ),
              ],
            ),
          ),
          // استعادة عبر Telegram
          Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                const Icon(Icons.telegram,
                    size: 80, color: Color(0xFF229ED9)),
                const SizedBox(height: 16),
                const Text(
                  'استخدم بوت Telegram لإستعادة كلمة المرور بشكل آمن.\nسيرسل البوت رابط إعادة التعيين مباشرة إلى حسابك.',
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF229ED9),
                    ),
                    icon: const Icon(Icons.telegram),
                    label: Text(t.t('open_telegram_bot')),
                    onPressed: _telegramRecovery,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
