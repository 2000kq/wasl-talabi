import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/locale_provider.dart';
import '../../core/theme/app_theme.dart';
import '../../localization/app_localizations.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final localeProv = context.watch<LocaleProvider>();
    final t = AppLocalizations.of(context)!;
    return Scaffold(
      appBar: AppBar(title: Text(t.t('settings'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    const Icon(Icons.language, color: AppColors.primary),
                    const SizedBox(width: 8),
                    Text(t.t('language'),
                        style:
                            const TextStyle(fontWeight: FontWeight.bold)),
                  ]),
                  const SizedBox(height: 8),
                  RadioListTile<String>(
                    title: Text(t.t('arabic')),
                    value: 'ar',
                    groupValue: localeProv.locale.languageCode,
                    onChanged: (v) => localeProv.setLocale(v!),
                  ),
                  RadioListTile<String>(
                    title: Text(t.t('english')),
                    value: 'en',
                    groupValue: localeProv.locale.languageCode,
                    onChanged: (v) => localeProv.setLocale(v!),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
