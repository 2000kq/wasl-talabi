import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../core/theme/app_theme.dart';
import '../../localization/app_localizations.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthProvider>().currentUser!;
    final t = AppLocalizations.of(context)!;
    return Scaffold(
      appBar: AppBar(title: Text(t.t('profile'))),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Center(
            child: CircleAvatar(
              radius: 50,
              backgroundColor: AppColors.primary,
              child: Text(
                user.name.isNotEmpty ? user.name[0].toUpperCase() : '?',
                style: const TextStyle(fontSize: 36, color: Colors.white),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Center(
              child: Text(user.name,
                  style: const TextStyle(
                      fontSize: 22, fontWeight: FontWeight.bold))),
          const SizedBox(height: 24),
          _tile(Icons.email, t.t('email'), user.email),
          _tile(Icons.phone, t.t('phone'), user.phone),
          _tile(Icons.badge, 'الدور',
              user.isAdmin ? 'مدير' : user.isDriver ? 'سائق' : 'عميل'),
          if (user.isDriver) ...[
            _tile(Icons.local_shipping, t.t('vehicle_type'),
                user.vehicleType ?? ''),
            _tile(Icons.confirmation_number, t.t('vehicle_plate'),
                user.vehiclePlate ?? ''),
            _tile(Icons.star, t.t('rating'),
                '${user.rating.toStringAsFixed(1)} (${user.totalRatings})'),
          ],
        ],
      ),
    );
  }

  Widget _tile(IconData icon, String label, String value) {
    return Card(
      child: ListTile(
        leading: Icon(icon, color: AppColors.primary),
        title: Text(label),
        subtitle: Text(value),
      ),
    );
  }
}
