import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/admin_provider.dart';
import '../../models/user_model.dart';
import '../../core/theme/app_theme.dart';
import '../../core/constants/app_constants.dart';
import '../../localization/app_localizations.dart';

class ManageUsersScreen extends StatelessWidget {
  const ManageUsersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    return Scaffold(
      appBar: AppBar(title: Text(t.t('manage_users'))),
      body: StreamBuilder<List<UserModel>>(
        stream: context.read<AdminProvider>().getAllUsers(),
        builder: (context, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final users = snap.data!.where((u) => !u.isAdmin).toList();
          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: users.length,
            itemBuilder: (_, i) => _UserTile(user: users[i]),
          );
        },
      ),
    );
  }
}

class _UserTile extends StatelessWidget {
  final UserModel user;
  const _UserTile({required this.user});

  Future<void> _promote(BuildContext context) async {
    String selectedVehicle = AppConstants.vehicleTypes.first['id'];
    final plateCtrl = TextEditingController();
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('ترقية إلى سائق'),
        content: StatefulBuilder(builder: (context, setSt) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DropdownButtonFormField<String>(
                value: selectedVehicle,
                decoration: const InputDecoration(labelText: 'نوع المركبة'),
                items: AppConstants.vehicleTypes
                    .map((v) => DropdownMenuItem<String>(
                          value: v['id'],
                          child: Text(v['name_ar']),
                        ))
                    .toList(),
                onChanged: (v) => setSt(() => selectedVehicle = v!),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: plateCtrl,
                decoration: const InputDecoration(labelText: 'رقم اللوحة'),
              ),
            ],
          );
        }),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () async {
              await context.read<AdminProvider>().promoteToDriver(
                    userId: user.uid,
                    vehicleType: selectedVehicle,
                    vehiclePlate: plateCtrl.text.trim(),
                  );
              if (context.mounted) Navigator.pop(context);
            },
            child: const Text('تأكيد'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor:
              user.isBlocked ? AppColors.error : AppColors.primary,
          child: Text(
            user.name.isNotEmpty ? user.name[0].toUpperCase() : '?',
            style: const TextStyle(color: Colors.white),
          ),
        ),
        title: Text(user.name),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(user.email),
            Text(user.phone),
            Container(
              margin: const EdgeInsets.only(top: 4),
              padding:
                  const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: user.isDriver
                    ? Colors.teal.withOpacity(0.2)
                    : Colors.blue.withOpacity(0.2),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                user.isDriver ? 'سائق' : 'عميل',
                style: const TextStyle(fontSize: 10),
              ),
            ),
          ],
        ),
        trailing: PopupMenuButton<String>(
          onSelected: (val) async {
            final prov = context.read<AdminProvider>();
            if (val == 'block') {
              await prov.toggleBlockUser(user.uid, !user.isBlocked);
            } else if (val == 'promote') {
              await _promote(context);
            } else if (val == 'demote') {
              await prov.demoteToCustomer(user.uid);
            }
          },
          itemBuilder: (_) => [
            PopupMenuItem(
              value: 'block',
              child: Text(user.isBlocked ? 'إلغاء الحظر' : 'حظر'),
            ),
            if (!user.isDriver)
              const PopupMenuItem(
                  value: 'promote', child: Text('ترقية إلى سائق')),
            if (user.isDriver)
              const PopupMenuItem(value: 'demote', child: Text('تخفيض')),
          ],
        ),
      ),
    );
  }
}
