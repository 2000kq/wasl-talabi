import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../providers/admin_provider.dart';
import '../../core/theme/app_theme.dart';
import '../../localization/app_localizations.dart';
import '../../routes/app_routes.dart';

/// لوحة الأدمن الرئيسية - الإحصائيات والوصول السريع للوحدات
class AdminDashboardScreen extends StatelessWidget {
  const AdminDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    return Scaffold(
      appBar: AppBar(
        title: Text(t.t('admin_dashboard')),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              await context.read<AuthProvider>().logout();
              if (context.mounted) {
                Navigator.pushNamedAndRemoveUntil(
                    context, AppRoutes.login, (_) => false);
              }
            },
          ),
        ],
      ),
      body: FutureBuilder<Map<String, dynamic>>(
        future: context.read<AdminProvider>().getDashboardStats(),
        builder: (context, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final s = snap.data!;
          return RefreshIndicator(
            onRefresh: () async {
              (context as Element).markNeedsBuild();
            },
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Text(t.t('statistics'),
                    style: const TextStyle(
                        fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                GridView.count(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisCount: 2,
                  mainAxisSpacing: 12,
                  crossAxisSpacing: 12,
                  childAspectRatio: 1.4,
                  children: [
                    _statCard(Icons.people, t.t('total_users'),
                        '${s['totalUsers']}', AppColors.primary),
                    _statCard(Icons.shopping_bag, 'الطلبات',
                        '${s['totalOrders']}', AppColors.secondary),
                    _statCard(Icons.person, t.t('customers'),
                        '${s['customers']}', Colors.purple),
                    _statCard(Icons.local_shipping, t.t('drivers'),
                        '${s['drivers']}', Colors.teal),
                    _statCard(Icons.check_circle, 'منجزة',
                        '${s['deliveredOrders']}', AppColors.success),
                    _statCard(
                        Icons.attach_money,
                        t.t('total_revenue'),
                        '${(s['totalRevenue'] as double).toStringAsFixed(0)} د.ع',
                        Colors.orange),
                  ],
                ),
                const SizedBox(height: 24),
                Text('الإدارة',
                    style: const TextStyle(
                        fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                _menuTile(
                  context,
                  Icons.people_outline,
                  t.t('manage_users'),
                  AppRoutes.manageUsers,
                ),
                _menuTile(
                  context,
                  Icons.price_change,
                  t.t('manage_pricing'),
                  AppRoutes.managePricing,
                ),
                _menuTile(
                  context,
                  Icons.list_alt,
                  t.t('all_orders'),
                  AppRoutes.allOrders,
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _statCard(IconData icon, String label, String value, Color color) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 30),
            const SizedBox(height: 8),
            Text(value,
                style: const TextStyle(
                    fontSize: 18, fontWeight: FontWeight.bold)),
            Text(label,
                style: const TextStyle(color: Colors.grey, fontSize: 12),
                textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }

  Widget _menuTile(
      BuildContext context, IconData icon, String title, String route) {
    return Card(
      child: ListTile(
        leading:
            Icon(icon, color: AppColors.primary, size: 30),
        title: Text(title),
        trailing: const Icon(Icons.arrow_forward_ios, size: 18),
        onTap: () => Navigator.pushNamed(context, route),
      ),
    );
  }
}
