import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/admin_provider.dart';
import '../../models/vehicle_pricing_model.dart';
import '../../core/theme/app_theme.dart';

class ManagePricingScreen extends StatelessWidget {
  const ManagePricingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إدارة الأسعار')),
      body: StreamBuilder<List<VehiclePricing>>(
        stream: context.read<AdminProvider>().getVehiclePricings(),
        builder: (context, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final list = snap.data!;
          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: list.length,
            itemBuilder: (_, i) => _PricingTile(pricing: list[i]),
          );
        },
      ),
    );
  }
}

class _PricingTile extends StatelessWidget {
  final VehiclePricing pricing;
  const _PricingTile({required this.pricing});

  Future<void> _edit(BuildContext context) async {
    final ctrl = TextEditingController(text: pricing.pricePerKm.toString());
    await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text('تعديل سعر ${pricing.nameAr}'),
        content: TextField(
          controller: ctrl,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(
            labelText: 'السعر لكل كم (د.ع)',
            prefixIcon: Icon(Icons.attach_money),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () async {
              final newPrice = double.tryParse(ctrl.text);
              if (newPrice == null) return;
              final updated = VehiclePricing(
                id: pricing.id,
                nameAr: pricing.nameAr,
                nameEn: pricing.nameEn,
                pricePerKm: newPrice,
                maxWeightKg: pricing.maxWeightKg,
                isActive: pricing.isActive,
              );
              await context
                  .read<AdminProvider>()
                  .updateVehiclePricing(updated);
              if (context.mounted) Navigator.pop(context);
            },
            child: const Text('حفظ'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: const CircleAvatar(
          backgroundColor: AppColors.primary,
          child: Icon(Icons.local_shipping, color: Colors.white),
        ),
        title: Text(pricing.nameAr),
        subtitle: Text('${pricing.pricePerKm.toStringAsFixed(0)} د.ع لكل كم'),
        trailing: IconButton(
          icon: const Icon(Icons.edit, color: AppColors.primary),
          onPressed: () => _edit(context),
        ),
      ),
    );
  }
}
