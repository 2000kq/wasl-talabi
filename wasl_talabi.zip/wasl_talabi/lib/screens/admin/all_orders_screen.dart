import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/admin_provider.dart';
import '../../models/order_model.dart';
import '../../widgets/order_card.dart';
import '../../routes/app_routes.dart';

class AllOrdersScreen extends StatelessWidget {
  const AllOrdersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('جميع الطلبات')),
      body: StreamBuilder<List<OrderModel>>(
        stream: context.read<AdminProvider>().getAllOrders(),
        builder: (context, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final orders = snap.data!;
          if (orders.isEmpty) {
            return const Center(child: Text('لا توجد طلبات'));
          }
          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: orders.length,
            itemBuilder: (_, i) => OrderCard(
              order: orders[i],
              onTap: () => Navigator.pushNamed(
                context,
                AppRoutes.orderTracking,
                arguments: orders[i].id,
              ),
            ),
          );
        },
      ),
    );
  }
}
