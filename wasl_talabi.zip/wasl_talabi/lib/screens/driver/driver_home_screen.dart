import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:latlong2/latlong.dart';
import '../../providers/auth_provider.dart';
import '../../providers/driver_provider.dart';
import '../../providers/order_provider.dart';
import '../../models/order_model.dart';
import '../../core/services/location_service.dart';
import '../../core/theme/app_theme.dart';
import '../../localization/app_localizations.dart';
import '../../routes/app_routes.dart';

/// الشاشة الرئيسية للسائق - الطلبات القريبة + الإحصائيات
class DriverHomeScreen extends StatefulWidget {
  const DriverHomeScreen({super.key});

  @override
  State<DriverHomeScreen> createState() => _DriverHomeScreenState();
}

class _DriverHomeScreenState extends State<DriverHomeScreen> {
  int _currentIndex = 0;
  LatLng? _currentLocation;

  @override
  void initState() {
    super.initState();
    _initLocation();
  }

  Future<void> _initLocation() async {
    final loc = await LocationService.getCurrentLocation();
    if (mounted && loc != null) {
      setState(() => _currentLocation = loc);
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context)!;
    final user = context.watch<AuthProvider>().currentUser!;
    final driverProv = context.watch<DriverProvider>();

    final pages = [
      _buildNearbyTab(user.vehicleType ?? 'stuta', t),
      _buildMyOrdersTab(user.uid, t),
      _buildEarningsTab(user, t),
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text(t.t('app_name')),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Row(
              children: [
                Text(driverProv.isAvailable
                    ? t.t('available')
                    : t.t('unavailable')),
                Switch(
                  value: driverProv.isAvailable,
                  activeColor: AppColors.success,
                  onChanged: (v) => driverProv.setAvailability(user.uid, v),
                ),
              ],
            ),
          ),
        ],
      ),
      body: pages[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (i) => setState(() => _currentIndex = i),
        items: [
          BottomNavigationBarItem(
              icon: const Icon(Icons.location_searching),
              label: t.t('nearby_orders')),
          BottomNavigationBarItem(
              icon: const Icon(Icons.list_alt), label: t.t('orders')),
          BottomNavigationBarItem(
              icon: const Icon(Icons.account_balance_wallet),
              label: t.t('earnings')),
        ],
      ),
    );
  }

  Widget _buildNearbyTab(String vehicleType, AppLocalizations t) {
    if (_currentLocation == null) {
      return const Center(child: CircularProgressIndicator());
    }
    final driverProv = context.read<DriverProvider>();
    return StreamBuilder<List<OrderModel>>(
      stream: driverProv.watchNearbyOrders(
        vehicleType: vehicleType,
        driverLocation: _currentLocation!,
      ),
      builder: (context, snap) {
        if (!snap.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        final orders = snap.data!;
        if (orders.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.location_searching, size: 80, color: Colors.grey),
                const SizedBox(height: 12),
                Text(t.t('no_data')),
              ],
            ),
          );
        }
        return ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: orders.length,
          itemBuilder: (_, i) => _NearbyOrderCard(
            order: orders[i],
            driverLocation: _currentLocation!,
            onAccept: () => _acceptOrder(orders[i]),
          ),
        );
      },
    );
  }

  Future<void> _acceptOrder(OrderModel order) async {
    final user = context.read<AuthProvider>().currentUser!;
    final ok = await context.read<OrderProvider>().acceptOrderByDriver(
          orderId: order.id,
          driverId: user.uid,
          driverName: user.name,
          driverPhone: user.phone,
        );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(ok ? 'تم قبول الطلب' : 'الطلب محجوز من سائق آخر'),
        backgroundColor: ok ? AppColors.success : AppColors.error,
      ),
    );
    if (ok) {
      Navigator.pushNamed(context, AppRoutes.orderTracking,
          arguments: order.id);
    }
  }

  Widget _buildMyOrdersTab(String driverId, AppLocalizations t) {
    return StreamBuilder<List<OrderModel>>(
      stream: context.read<OrderProvider>().getDriverOrders(driverId),
      builder: (context, snap) {
        if (!snap.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        final orders = snap.data!;
        if (orders.isEmpty) {
          return Center(child: Text(t.t('no_data')));
        }
        return ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: orders.length,
          itemBuilder: (_, i) {
            final o = orders[i];
            return Card(
              child: ListTile(
                leading: const Icon(Icons.local_shipping,
                    color: AppColors.primary),
                title: Text(o.vehicleNameAr),
                subtitle: Text('${o.distanceKm.toStringAsFixed(1)} كم'),
                trailing: Text(
                  '${o.totalPrice.toStringAsFixed(0)} د.ع',
                  style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      color: AppColors.success),
                ),
                onTap: () => Navigator.pushNamed(
                    context, AppRoutes.orderTracking, arguments: o.id),
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildEarningsTab(user, AppLocalizations t) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          Card(
            color: AppColors.primary,
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  const Icon(Icons.account_balance_wallet,
                      color: Colors.white, size: 50),
                  const SizedBox(height: 12),
                  Text(t.t('earnings'),
                      style: const TextStyle(color: Colors.white70)),
                  const SizedBox(height: 8),
                  Text(
                    '${user.totalEarnings.toStringAsFixed(0)} د.ع',
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 32,
                        fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        const Icon(Icons.check_circle,
                            color: AppColors.success, size: 32),
                        const SizedBox(height: 8),
                        Text('${user.totalOrders}',
                            style: const TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.bold)),
                        const Text('طلبات منجزة',
                            style: TextStyle(color: Colors.grey)),
                      ],
                    ),
                  ),
                ),
              ),
              Expanded(
                child: Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        const Icon(Icons.star, color: Colors.amber, size: 32),
                        const SizedBox(height: 8),
                        Text(user.rating.toStringAsFixed(1),
                            style: const TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.bold)),
                        Text('${user.totalRatings} تقييم',
                            style: const TextStyle(color: Colors.grey)),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
          const Spacer(),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
            icon: const Icon(Icons.logout),
            label: Text(t.t('logout')),
            onPressed: () async {
              await context.read<AuthProvider>().logout();
              if (context.mounted) {
                Navigator.pushNamedAndRemoveUntil(
                    context, AppRoutes.login, (_) => false);
              }
            },
          ),
        ],
      ),
    );
  }
}

class _NearbyOrderCard extends StatelessWidget {
  final OrderModel order;
  final LatLng driverLocation;
  final VoidCallback onAccept;

  const _NearbyOrderCard({
    required this.order,
    required this.driverLocation,
    required this.onAccept,
  });

  @override
  Widget build(BuildContext context) {
    final distanceToPickup = LocationService.distanceBetweenKm(
      driverLocation,
      LatLng(order.pickupLat, order.pickupLng),
    );
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.person, color: AppColors.primary),
                const SizedBox(width: 8),
                Text(order.customerName,
                    style: const TextStyle(fontWeight: FontWeight.bold)),
                const Spacer(),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: AppColors.secondary.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    '${distanceToPickup.toStringAsFixed(1)} كم',
                    style: const TextStyle(
                        color: AppColors.secondary,
                        fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(children: [
              const Icon(Icons.my_location,
                  color: AppColors.success, size: 16),
              const SizedBox(width: 6),
              Expanded(child: Text(order.pickupAddress, maxLines: 1)),
            ]),
            const SizedBox(height: 4),
            Row(children: [
              const Icon(Icons.location_on, color: AppColors.error, size: 16),
              const SizedBox(width: 6),
              Expanded(child: Text(order.destinationAddress, maxLines: 1)),
            ]),
            const Divider(),
            Row(
              children: [
                Text('${order.distanceKm.toStringAsFixed(1)} كم',
                    style: const TextStyle(color: Colors.grey)),
                const Spacer(),
                Text('${order.totalPrice.toStringAsFixed(0)} د.ع',
                    style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                        color: AppColors.success)),
              ],
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                style:
                    ElevatedButton.styleFrom(backgroundColor: AppColors.success),
                icon: const Icon(Icons.check),
                label: const Text('قبول الطلب'),
                onPressed: onAccept,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
