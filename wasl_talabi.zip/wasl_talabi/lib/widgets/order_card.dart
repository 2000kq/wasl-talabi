import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/order_model.dart';
import '../core/theme/app_theme.dart';

class OrderCard extends StatelessWidget {
  final OrderModel order;
  final VoidCallback onTap;

  const OrderCard({super.key, required this.order, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final dateStr = DateFormat('yyyy-MM-dd HH:mm').format(order.createdAt);
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(Icons.local_shipping, color: AppColors.primary),
                  const SizedBox(width: 8),
                  Text(order.vehicleNameAr,
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                  const Spacer(),
                  _statusChip(order.status),
                ],
              ),
              const SizedBox(height: 8),
              _row(Icons.my_location, order.pickupAddress, AppColors.success),
              const SizedBox(height: 4),
              _row(Icons.location_on, order.destinationAddress,
                  AppColors.error),
              const Divider(),
              Row(
                children: [
                  Text('${order.distanceKm.toStringAsFixed(1)} كم',
                      style: const TextStyle(color: Colors.grey)),
                  const Spacer(),
                  Text('${order.totalPrice.toStringAsFixed(0)} د.ع',
                      style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          color: AppColors.success)),
                ],
              ),
              const SizedBox(height: 4),
              Text(dateStr,
                  style: const TextStyle(fontSize: 12, color: Colors.grey)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _row(IconData icon, String text, Color color) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, color: color, size: 16),
        const SizedBox(width: 6),
        Expanded(
            child: Text(text, maxLines: 1, overflow: TextOverflow.ellipsis)),
      ],
    );
  }

  Widget _statusChip(String status) {
    Color c;
    String label;
    switch (status) {
      case 'pending':
        c = AppColors.warning;
        label = 'قيد الانتظار';
        break;
      case 'accepted':
      case 'picked_up':
      case 'in_transit':
        c = AppColors.primary;
        label = 'قيد التنفيذ';
        break;
      case 'delivered':
        c = AppColors.success;
        label = 'تم التسليم';
        break;
      case 'cancelled':
        c = AppColors.error;
        label = 'ملغي';
        break;
      default:
        c = Colors.grey;
        label = status;
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: c.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(label,
          style: TextStyle(
              color: c, fontSize: 12, fontWeight: FontWeight.bold)),
    );
  }
}
