/// ثوابت التطبيق العامة
class AppConstants {
  // أدوار المستخدمين
  static const String roleCustomer = 'customer';
  static const String roleDriver = 'driver';
  static const String roleAdmin = 'admin';

  // حالات الطلبات
  static const String orderPending = 'pending';
  static const String orderAccepted = 'accepted';
  static const String orderPickedUp = 'picked_up';
  static const String orderInTransit = 'in_transit';
  static const String orderDelivered = 'delivered';
  static const String orderCancelled = 'cancelled';

  // أنواع المركبات
  static const List<Map<String, dynamic>> vehicleTypes = [
    {
      'id': 'stuta',
      'name_ar': 'ستوتة',
      'name_en': 'Stuta',
      'icon': 'assets/icons/stuta.png',
      'default_price_per_km': 500.0,
      'max_weight_kg': 100,
    },
    {
      'id': 'tuktuk',
      'name_ar': 'توك توك',
      'name_en': 'Tuk Tuk',
      'icon': 'assets/icons/tuktuk.png',
      'default_price_per_km': 600.0,
      'max_weight_kg': 200,
    },
    {
      'id': 'pickup',
      'name_ar': 'بيك آب',
      'name_en': 'Pickup',
      'icon': 'assets/icons/pickup.png',
      'default_price_per_km': 1000.0,
      'max_weight_kg': 1000,
    },
    {
      'id': 'truck_1ton',
      'name_ar': 'حمل 1 طن',
      'name_en': '1 Ton',
      'icon': 'assets/icons/truck_1t.png',
      'default_price_per_km': 1500.0,
      'max_weight_kg': 1000,
    },
    {
      'id': 'truck_3ton',
      'name_ar': 'حمل 3 طن',
      'name_en': '3 Ton',
      'icon': 'assets/icons/truck_3t.png',
      'default_price_per_km': 2500.0,
      'max_weight_kg': 3000,
    },
    {
      'id': 'truck_5ton',
      'name_ar': 'حمل 5 طن',
      'name_en': '5 Ton',
      'icon': 'assets/icons/truck_5t.png',
      'default_price_per_km': 4000.0,
      'max_weight_kg': 5000,
    },
  ];

  // العملة
  static const String currency = 'IQD';
  static const String currencyAr = 'د.ع';

  // رسائل الإشعارات
  static const String fcmTopicAllDrivers = 'all_drivers';
  static const String fcmTopicAllCustomers = 'all_customers';
}
