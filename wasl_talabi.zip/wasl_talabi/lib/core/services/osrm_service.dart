import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:hive/hive.dart';
import 'package:latlong2/latlong.dart';
import '../../config/app_config.dart';

/// خدمة OSRM لحساب المسافة والمسار باستخدام OpenStreetMap
class OSRMService {
  /// جلب المسار بين نقطتين
  /// إرجاع: { 'distance': km, 'duration': sec, 'coordinates': [[lat, lng], ...] }
  static Future<Map<String, dynamic>?> getRoute({
    required LatLng start,
    required LatLng end,
    bool cacheLocally = true,
  }) async {
    final cacheKey =
        '${start.latitude},${start.longitude}_${end.latitude},${end.longitude}';

    try {
      final url = Uri.parse(
        '${AppConfig.osrmRoutingUrl}/route/v1/driving/'
        '${start.longitude},${start.latitude};'
        '${end.longitude},${end.latitude}'
        '?overview=full&geometries=geojson&steps=true',
      );

      final response = await http.get(url).timeout(
            const Duration(seconds: 15),
          );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['routes'] != null && (data['routes'] as List).isNotEmpty) {
          final route = data['routes'][0];
          final distanceKm = (route['distance'] as num) / 1000.0;
          final durationSec = (route['duration'] as num).toDouble();
          final coords = (route['geometry']['coordinates'] as List)
              .map<List<double>>(
                (c) => [(c[1] as num).toDouble(), (c[0] as num).toDouble()],
              )
              .toList();

          final result = {
            'distance': distanceKm,
            'duration': durationSec,
            'coordinates': coords,
            'cached_at': DateTime.now().toIso8601String(),
          };

          // حفظ المسار محلياً للوضع غير المتصل
          if (cacheLocally) {
            final box = Hive.box('routes_cache');
            await box.put(cacheKey, result);
          }

          return result;
        }
      }
    } catch (e) {
      // محاولة جلب المسار من الكاش المحلي عند فشل الشبكة
      if (cacheLocally) {
        final box = Hive.box('routes_cache');
        final cached = box.get(cacheKey);
        if (cached != null) {
          return Map<String, dynamic>.from(cached as Map);
        }
      }
    }
    return null;
  }

  /// تحويل عنوان نصي إلى إحداثيات (Geocoding)
  static Future<LatLng?> geocode(String address) async {
    try {
      final url = Uri.parse(
        '${AppConfig.nominatimUrl}/search?q=${Uri.encodeComponent(address)}&format=json&limit=1',
      );
      final response = await http.get(
        url,
        headers: {'User-Agent': 'WaslTalabi/1.0'},
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = json.decode(response.body) as List;
        if (data.isNotEmpty) {
          return LatLng(
            double.parse(data[0]['lat']),
            double.parse(data[0]['lon']),
          );
        }
      }
    } catch (_) {}
    return null;
  }

  /// تحويل إحداثيات إلى عنوان نصي (Reverse Geocoding)
  static Future<String?> reverseGeocode(LatLng location) async {
    try {
      final url = Uri.parse(
        '${AppConfig.nominatimUrl}/reverse?lat=${location.latitude}'
        '&lon=${location.longitude}&format=json&accept-language=ar',
      );
      final response = await http.get(
        url,
        headers: {'User-Agent': 'WaslTalabi/1.0'},
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return data['display_name'] as String?;
      }
    } catch (_) {}
    return null;
  }

  /// حساب المسافة المباشرة بين نقطتين (Haversine)
  static double calculateDistance(LatLng a, LatLng b) {
    final distance = const Distance().as(LengthUnit.Kilometer, a, b);
    return distance;
  }

  /// جلب المسار المخزن محلياً
  static Map<String, dynamic>? getCachedRoute(LatLng start, LatLng end) {
    final cacheKey =
        '${start.latitude},${start.longitude}_${end.latitude},${end.longitude}';
    final box = Hive.box('routes_cache');
    final cached = box.get(cacheKey);
    if (cached != null) {
      return Map<String, dynamic>.from(cached as Map);
    }
    return null;
  }
}
