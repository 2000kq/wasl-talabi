import 'dart:convert';
import 'package:http/http.dart' as http;
import '../../config/app_config.dart';

/// خدمة استعادة كلمة المرور عبر Telegram Bot
/// ⚠️ يجب أن يكون Token محفوظاً في Cloud Functions، لا في التطبيق
class TelegramService {
  /// إرسال طلب استعادة كلمة المرور
  /// يستدعي Cloud Function الذي يتعامل مع Telegram Bot
  static Future<bool> sendPasswordResetRequest({
    required String email,
    required String telegramUsername,
  }) async {
    try {
      final response = await http.post(
        Uri.parse(AppConfig.passwordResetEndpoint),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'email': email,
          'telegramUsername': telegramUsername,
        }),
      );
      return response.statusCode == 200;
    } catch (_) {
      return false;
    }
  }

  /// رابط فتح البوت مباشرة في تطبيق Telegram
  static String getBotDeepLink({String? startParam}) {
    final base = 'https://t.me/${AppConfig.telegramBotUsername}';
    return startParam != null ? '$base?start=$startParam' : base;
  }
}
