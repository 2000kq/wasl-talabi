import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';

/// خدمة تحديد المواقع GPS
class LocationService {
  /// التأكد من تفعيل GPS والحصول على الإذن
  static Future<bool> ensurePermissions() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) return false;

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) return false;
    }
    if (permission == LocationPermission.deniedForever) return false;
    return true;
  }

  /// الحصول على الموقع الحالي
  static Future<LatLng?> getCurrentLocation() async {
    final ok = await ensurePermissions();
    if (!ok) return null;
    try {
      final pos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      return LatLng(pos.latitude, pos.longitude);
    } catch (_) {
      return null;
    }
  }

  /// تدفق مستمر لتحديثات الموقع (للسائقين)
  static Stream<Position> getPositionStream({
    int distanceFilter = 10,
  }) {
    return Geolocator.getPositionStream(
      locationSettings: LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: distanceFilter,
      ),
    );
  }

  /// حساب المسافة بين نقطتين بالكيلومترات
  static double distanceBetweenKm(LatLng a, LatLng b) {
    final meters = Geolocator.distanceBetween(
      a.latitude,
      a.longitude,
      b.latitude,
      b.longitude,
    );
    return meters / 1000.0;
  }
}
