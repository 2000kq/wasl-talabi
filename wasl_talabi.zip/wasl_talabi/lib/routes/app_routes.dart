import 'package:flutter/material.dart';
import '../screens/shared/splash_screen.dart';
import '../screens/auth/login_screen.dart';
import '../screens/auth/register_screen.dart';
import '../screens/auth/forgot_password_screen.dart';
import '../screens/customer/customer_home_screen.dart';
import '../screens/customer/create_order_screen.dart';
import '../screens/customer/order_tracking_screen.dart';
import '../screens/driver/driver_home_screen.dart';
import '../screens/admin/admin_dashboard_screen.dart';
import '../screens/admin/manage_users_screen.dart';
import '../screens/admin/manage_pricing_screen.dart';
import '../screens/admin/all_orders_screen.dart';
import '../screens/shared/chat_screen.dart';
import '../screens/shared/profile_screen.dart';
import '../screens/shared/settings_screen.dart';

/// مسارات التطبيق
class AppRoutes {
  static const String splash = '/';
  static const String login = '/login';
  static const String register = '/register';
  static const String forgotPassword = '/forgot_password';
  static const String customerHome = '/customer_home';
  static const String createOrder = '/create_order';
  static const String orderTracking = '/order_tracking';
  static const String driverHome = '/driver_home';
  static const String adminDashboard = '/admin_dashboard';
  static const String manageUsers = '/manage_users';
  static const String managePricing = '/manage_pricing';
  static const String allOrders = '/all_orders';
  static const String chat = '/chat';
  static const String profile = '/profile';
  static const String settings = '/settings';

  static Map<String, WidgetBuilder> get routes => {
        splash: (_) => const SplashScreen(),
        login: (_) => const LoginScreen(),
        register: (_) => const RegisterScreen(),
        forgotPassword: (_) => const ForgotPasswordScreen(),
        customerHome: (_) => const CustomerHomeScreen(),
        createOrder: (_) => const CreateOrderScreen(),
        driverHome: (_) => const DriverHomeScreen(),
        adminDashboard: (_) => const AdminDashboardScreen(),
        manageUsers: (_) => const ManageUsersScreen(),
        managePricing: (_) => const ManagePricingScreen(),
        allOrders: (_) => const AllOrdersScreen(),
        profile: (_) => const ProfileScreen(),
        settings: (_) => const SettingsScreen(),
      };

  static Route<dynamic>? onGenerateRoute(RouteSettings settings) {
    if (settings.name == orderTracking) {
      final orderId = settings.arguments as String;
      return MaterialPageRoute(
        builder: (_) => OrderTrackingScreen(orderId: orderId),
      );
    }
    if (settings.name == chat) {
      final args = settings.arguments as Map<String, dynamic>;
      return MaterialPageRoute(
        builder: (_) => ChatScreen(
          orderId: args['orderId'],
          otherUserName: args['otherUserName'],
        ),
      );
    }
    return null;
  }
}
