// File generated for Wasl Talabi based on google-services.json
// المشروع: wasltalabi

import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not configured for this platform.',
        );
    }
  }

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyDIwMgJJzTLObW863KV2zCdl7j7ccNTxKU',
    appId: '1:106348294003:android:520a2364750f88a06e5f06',
    messagingSenderId: '106348294003',
    projectId: 'wasltalabi',
    storageBucket: 'wasltalabi.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyDIwMgJJzTLObW863KV2zCdl7j7ccNTxKU',
    appId: '1:106348294003:ios:placeholder',
    messagingSenderId: '106348294003',
    projectId: 'wasltalabi',
    storageBucket: 'wasltalabi.firebasestorage.app',
    iosBundleId: 'com.wasl.talabi',
  );

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyDIwMgJJzTLObW863KV2zCdl7j7ccNTxKU',
    appId: '1:106348294003:web:placeholder',
    messagingSenderId: '106348294003',
    projectId: 'wasltalabi',
    storageBucket: 'wasltalabi.firebasestorage.app',
  );
}
