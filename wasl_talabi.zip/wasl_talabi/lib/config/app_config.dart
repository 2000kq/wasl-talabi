/// إعدادات التطبيق المركزية
/// Centralized application configuration
class AppConfig {
  // معلومات التطبيق - App Info
  static const String appName = 'وصل طلبي';
  static const String appNameEn = 'Wasl Talabi';
  static const String appVersion = '1.0.0';

  // ============ Firebase Configuration ============
  // القيم الفعلية من google-services.json
  static const String firebaseProjectId = 'wasltalabi';
  static const String firebaseApiKey = 'AIzaSyDIwMgJJzTLObW863KV2zCdl7j7ccNTxKU';
  static const String firebaseAppId = '1:106348294003:android:520a2364750f88a06e5f06';
  static const String firebaseMessagingSenderId = '106348294003';
  static const String firebaseStorageBucket = 'wasltalabi.firebasestorage.app';

  // ============ Admin Account ============
  // بيانات الأدمن الافتراضية للاختبار
  // ⚠️ يجب تغييرها بعد أول تسجيل دخول في الإنتاج
  static const String adminEmail = 'admin@wasltalabi.com';
  static const String adminPhone = '+9647700000000';
  static const String adminPassword = 'Wasl@Admin2025!';

  // ============ Telegram Bot Integration ============
  // ⚠️ هذه المعرفات placeholders. ضعها في Cloud Functions، لا في تطبيق العميل
  static const String telegramBotToken = 'YOUR_TELEGRAM_BOT_TOKEN';
  static const String telegramBotUsername = 'WaslTalabi_Bot';
  // نقطة نهاية Cloud Function لاستعادة كلمة المرور
  static const String passwordResetEndpoint =
      'https://us-central1-wasltalabi.cloudfunctions.net/sendPasswordResetTelegram';

  // ============ OpenStreetMap / OSRM ============
  static const String osmTileUrl =
      'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
  static const String osrmRoutingUrl = 'https://router.project-osrm.org';
  static const String nominatimUrl = 'https://nominatim.openstreetmap.org';

  // ============ Order Logic ============
  // نصف القطر الذي يستقبل ضمنه السائقون الطلبات (كم)
  static const double driverSearchRadiusKm = 5.0;
  // المسافة الافتراضية للحد الأدنى للسعر
  static const double minimumDistanceKm = 1.0;
  // مهلة قبول الطلب من السائق (ثوانٍ)
  static const int orderAcceptanceTimeoutSec = 60;
  // تحديث موقع السائق كل (ثوانٍ)
  static const int driverLocationUpdateIntervalSec = 5;

  // ============ Map Defaults ============
  // المركز الافتراضي للخريطة (بغداد - العراق)
  static const double defaultLatitude = 33.3152;
  static const double defaultLongitude = 44.3661;
  static const double defaultZoom = 13.0;

  // ============ Firestore Collections ============
  static const String usersCollection = 'users';
  static const String ordersCollection = 'orders';
  static const String vehiclesCollection = 'vehicles';
  static const String chatsCollection = 'chats';
  static const String ratingsCollection = 'ratings';
  static const String settingsCollection = 'settings';
  static const String notificationsCollection = 'notifications';
}
