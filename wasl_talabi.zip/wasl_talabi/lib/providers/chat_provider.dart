import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/chat_message_model.dart';
import '../config/app_config.dart';

/// مزود الدردشة - رسائل لحظية بين العميل والسائق لكل طلب
class ChatProvider extends ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  /// إرسال رسالة
  Future<void> sendMessage({
    required String orderId,
    required String senderId,
    required String senderName,
    required String message,
  }) async {
    await _firestore
        .collection(AppConfig.chatsCollection)
        .doc(orderId)
        .collection('messages')
        .add({
      'orderId': orderId,
      'senderId': senderId,
      'senderName': senderName,
      'message': message,
      'timestamp': FieldValue.serverTimestamp(),
      'isRead': false,
    });
  }

  /// تدفق رسائل الطلب
  Stream<List<ChatMessage>> watchMessages(String orderId) {
    return _firestore
        .collection(AppConfig.chatsCollection)
        .doc(orderId)
        .collection('messages')
        .orderBy('timestamp', descending: false)
        .snapshots()
        .map((s) => s.docs
            .map((d) => ChatMessage.fromMap(d.data(), d.id))
            .toList());
  }

  /// تعليم الرسائل كمقروءة
  Future<void> markAsRead(String orderId, String userId) async {
    final messages = await _firestore
        .collection(AppConfig.chatsCollection)
        .doc(orderId)
        .collection('messages')
        .where('isRead', isEqualTo: false)
        .where('senderId', isNotEqualTo: userId)
        .get();
    for (final doc in messages.docs) {
      await doc.reference.update({'isRead': true});
    }
  }
}
