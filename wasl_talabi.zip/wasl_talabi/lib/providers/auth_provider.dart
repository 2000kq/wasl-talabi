import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/user_model.dart';
import '../config/app_config.dart';

/// مزود المصادقة - تسجيل الدخول والتسجيل وإدارة الجلسة
class AuthProvider extends ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  UserModel? _currentUser;
  bool _isLoading = false;
  String? _errorMessage;

  UserModel? get currentUser => _currentUser;
  bool get isLoading => _isLoading;
  bool get isAuthenticated => _currentUser != null;
  String? get errorMessage => _errorMessage;

  void _setLoading(bool v) {
    _isLoading = v;
    notifyListeners();
  }

  /// تحميل بيانات المستخدم من Firestore
  Future<void> loadCurrentUser() async {
    final firebaseUser = _auth.currentUser;
    if (firebaseUser == null) {
      _currentUser = null;
      notifyListeners();
      return;
    }
    final doc =
        await _firestore.collection(AppConfig.usersCollection).doc(firebaseUser.uid).get();
    if (doc.exists) {
      _currentUser = UserModel.fromMap(doc.data()!, doc.id);
      notifyListeners();
    }
  }

  /// تسجيل الدخول بالبريد وكلمة المرور
  Future<bool> loginWithEmail(String email, String password) async {
    _setLoading(true);
    _errorMessage = null;
    try {
      // فحص حساب الأدمن الافتراضي
      if (email == AppConfig.adminEmail && password == AppConfig.adminPassword) {
        await _ensureAdminAccountExists();
      }

      final credential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      final doc = await _firestore
          .collection(AppConfig.usersCollection)
          .doc(credential.user!.uid)
          .get();

      if (doc.exists) {
        _currentUser = UserModel.fromMap(doc.data()!, doc.id);
        if (_currentUser!.isBlocked) {
          await _auth.signOut();
          _errorMessage = 'تم حظر حسابك. تواصل مع الإدارة.';
          _currentUser = null;
          _setLoading(false);
          return false;
        }
        // تحديث آخر ظهور
        await _firestore
            .collection(AppConfig.usersCollection)
            .doc(credential.user!.uid)
            .update({'lastSeen': FieldValue.serverTimestamp()});
        _setLoading(false);
        return true;
      } else {
        _errorMessage = 'لم يتم العثور على بيانات المستخدم';
        _setLoading(false);
        return false;
      }
    } on FirebaseAuthException catch (e) {
      _errorMessage = _mapAuthError(e.code);
      _setLoading(false);
      return false;
    } catch (e) {
      _errorMessage = 'حدث خطأ غير متوقع';
      _setLoading(false);
      return false;
    }
  }

  /// إنشاء حساب الأدمن تلقائياً عند أول تسجيل دخول
  Future<void> _ensureAdminAccountExists() async {
    try {
      await _auth.createUserWithEmailAndPassword(
        email: AppConfig.adminEmail,
        password: AppConfig.adminPassword,
      );
      final uid = _auth.currentUser!.uid;
      final adminUser = UserModel(
        uid: uid,
        name: 'مدير النظام',
        email: AppConfig.adminEmail,
        phone: AppConfig.adminPhone,
        role: 'admin',
        createdAt: DateTime.now(),
      );
      await _firestore
          .collection(AppConfig.usersCollection)
          .doc(uid)
          .set(adminUser.toMap());
    } catch (_) {
      // الحساب موجود مسبقاً - تجاهل
    }
  }

  /// إنشاء حساب جديد
  Future<bool> registerWithEmail({
    required String name,
    required String email,
    required String phone,
    required String password,
  }) async {
    _setLoading(true);
    _errorMessage = null;
    try {
      final credential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      final newUser = UserModel(
        uid: credential.user!.uid,
        name: name,
        email: email,
        phone: phone,
        role: 'customer',
        createdAt: DateTime.now(),
      );

      await _firestore
          .collection(AppConfig.usersCollection)
          .doc(credential.user!.uid)
          .set(newUser.toMap());

      _currentUser = newUser;
      _setLoading(false);
      return true;
    } on FirebaseAuthException catch (e) {
      _errorMessage = _mapAuthError(e.code);
      _setLoading(false);
      return false;
    }
  }

  /// تسجيل الدخول بالهاتف (إرسال OTP)
  Future<void> sendPhoneOTP({
    required String phoneNumber,
    required Function(String verificationId) onCodeSent,
    required Function(String error) onError,
  }) async {
    await _auth.verifyPhoneNumber(
      phoneNumber: phoneNumber,
      verificationCompleted: (PhoneAuthCredential credential) async {
        await _auth.signInWithCredential(credential);
      },
      verificationFailed: (FirebaseAuthException e) {
        onError(_mapAuthError(e.code));
      },
      codeSent: (String verificationId, int? resendToken) {
        onCodeSent(verificationId);
      },
      codeAutoRetrievalTimeout: (_) {},
    );
  }

  /// التحقق من رمز OTP
  Future<bool> verifyPhoneOTP({
    required String verificationId,
    required String smsCode,
    required String name,
    required String phone,
  }) async {
    _setLoading(true);
    try {
      final credential = PhoneAuthProvider.credential(
        verificationId: verificationId,
        smsCode: smsCode,
      );
      final result = await _auth.signInWithCredential(credential);
      final uid = result.user!.uid;

      // إنشاء وثيقة مستخدم إن لم تكن موجودة
      final doc = await _firestore
          .collection(AppConfig.usersCollection)
          .doc(uid)
          .get();
      if (!doc.exists) {
        final newUser = UserModel(
          uid: uid,
          name: name,
          email: '',
          phone: phone,
          role: 'customer',
          createdAt: DateTime.now(),
        );
        await _firestore
            .collection(AppConfig.usersCollection)
            .doc(uid)
            .set(newUser.toMap());
        _currentUser = newUser;
      } else {
        _currentUser = UserModel.fromMap(doc.data()!, doc.id);
      }
      _setLoading(false);
      return true;
    } catch (e) {
      _errorMessage = 'فشل التحقق من الرمز';
      _setLoading(false);
      return false;
    }
  }

  /// إعادة تعيين كلمة المرور عبر البريد الإلكتروني
  Future<bool> resetPasswordByEmail(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email);
      return true;
    } catch (e) {
      _errorMessage = 'فشل إرسال البريد';
      return false;
    }
  }

  /// تسجيل الخروج
  Future<void> logout() async {
    await _auth.signOut();
    _currentUser = null;
    notifyListeners();
  }

  /// ترجمة رموز الأخطاء
  String _mapAuthError(String code) {
    switch (code) {
      case 'user-not-found':
        return 'البريد الإلكتروني غير مسجل';
      case 'wrong-password':
        return 'كلمة المرور غير صحيحة';
      case 'invalid-email':
        return 'البريد الإلكتروني غير صالح';
      case 'email-already-in-use':
        return 'البريد مستخدم مسبقاً';
      case 'weak-password':
        return 'كلمة المرور ضعيفة (6 أحرف على الأقل)';
      case 'invalid-credential':
        return 'بيانات الدخول غير صحيحة';
      default:
        return 'حدث خطأ. حاول مرة أخرى';
    }
  }
}
