import 'dart:async';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:latlong2/latlong.dart';
import 'package:geolocator/geolocator.dart';
import '../models/order_model.dart';
import '../config/app_config.dart';
import '../core/services/location_service.dart';

/// مزود ميزات السائق - استقبال الطلبات القريبة وتحديث الموقع
class DriverProvider extends ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  StreamSubscription<Position>? _positionSub;

  List<OrderModel> _nearbyOrders = [];
  bool _isAvailable = false;
  LatLng? _currentLocation;

  List<OrderModel> get nearbyOrders => _nearbyOrders;
  bool get isAvailable => _isAvailable;
  LatLng? get currentLocation => _currentLocation;

  /// تبديل توفر السائق
  Future<void> setAvailability(String driverId, bool available) async {
    _isAvailable = available;
    notifyListeners();
    await _firestore
        .collection(AppConfig.usersCollection)
        .doc(driverId)
        .update({'isAvailable': available});

    if (available) {
      startLocationTracking(driverId);
    } else {
      stopLocationTracking();
    }
  }

  /// بدء تتبع الموقع للسائق
  void startLocationTracking(String driverId) {
    _positionSub?.cancel();
    _positionSub = LocationService.getPositionStream().listen((pos) async {
      _currentLocation = LatLng(pos.latitude, pos.longitude);
      notifyListeners();
      // تحديث موقع السائق في قاعدة البيانات
      await _firestore
          .collection(AppConfig.usersCollection)
          .doc(driverId)
          .update({
        'currentLat': pos.latitude,
        'currentLng': pos.longitude,
        'lastSeen': FieldValue.serverTimestamp(),
      });
    });
  }

  void stopLocationTracking() {
    _positionSub?.cancel();
    _positionSub = null;
  }

  /// تدفق الطلبات القريبة فقط
  Stream<List<OrderModel>> watchNearbyOrders({
    required String vehicleType,
    required LatLng driverLocation,
    double radiusKm = 5.0,
  }) {
    return _firestore
        .collection(AppConfig.ordersCollection)
        .where('status', isEqualTo: 'pending')
        .where('vehicleType', isEqualTo: vehicleType)
        .snapshots()
        .map((snap) {
      final orders = snap.docs
          .map((d) => OrderModel.fromMap(d.data(), d.id))
          .where((o) {
        final distKm = LocationService.distanceBetweenKm(
          driverLocation,
          LatLng(o.pickupLat, o.pickupLng),
        );
        return distKm <= radiusKm;
      }).toList();
      orders.sort((a, b) => a.createdAt.compareTo(b.createdAt));
      return orders;
    });
  }

  @override
  void dispose() {
    stopLocationTracking();
    super.dispose();
  }
}
