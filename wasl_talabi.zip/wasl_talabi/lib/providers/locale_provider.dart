import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// مزود اللغة - يدعم العربية (افتراضي) والإنجليزية
class LocaleProvider extends ChangeNotifier {
  Locale _locale = const Locale('ar', 'SA');
  Locale get locale => _locale;

  LocaleProvider() {
    _loadSavedLocale();
  }

  Future<void> _loadSavedLocale() async {
    final prefs = await SharedPreferences.getInstance();
    final code = prefs.getString('locale_code');
    if (code == 'en') {
      _locale = const Locale('en', 'US');
    } else {
      _locale = const Locale('ar', 'SA');
    }
    notifyListeners();
  }

  Future<void> setLocale(String code) async {
    _locale = code == 'en' ? const Locale('en', 'US') : const Locale('ar', 'SA');
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('locale_code', code);
    notifyListeners();
  }

  bool get isArabic => _locale.languageCode == 'ar';
}
