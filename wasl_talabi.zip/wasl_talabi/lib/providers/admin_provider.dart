import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/user_model.dart';
import '../models/order_model.dart';
import '../models/vehicle_pricing_model.dart';
import '../config/app_config.dart';
import '../core/constants/app_constants.dart';

/// مزود لوحة الأدمن - إدارة المستخدمين، الأسعار، والإحصائيات
class AdminProvider extends ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  /// جميع المستخدمين
  Stream<List<UserModel>> getAllUsers() {
    return _firestore
        .collection(AppConfig.usersCollection)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((s) => s.docs.map((d) => UserModel.fromMap(d.data(), d.id)).toList());
  }

  /// ترقية مستخدم إلى سائق
  Future<void> promoteToDriver({
    required String userId,
    required String vehicleType,
    required String vehiclePlate,
  }) async {
    await _firestore.collection(AppConfig.usersCollection).doc(userId).update({
      'role': 'driver',
      'vehicleType': vehicleType,
      'vehiclePlate': vehiclePlate,
    });
  }

  /// تخفيض سائق إلى عميل
  Future<void> demoteToCustomer(String userId) async {
    await _firestore.collection(AppConfig.usersCollection).doc(userId).update({
      'role': 'customer',
      'vehicleType': null,
      'vehiclePlate': null,
    });
  }

  /// حظر / فك حظر مستخدم
  Future<void> toggleBlockUser(String userId, bool block) async {
    await _firestore.collection(AppConfig.usersCollection).doc(userId).update({
      'isBlocked': block,
    });
  }

  /// تحديث السعر لنوع مركبة
  Future<void> updateVehiclePricing(VehiclePricing pricing) async {
    await _firestore
        .collection(AppConfig.vehiclesCollection)
        .doc(pricing.id)
        .set(pricing.toMap(), SetOptions(merge: true));
  }

  /// جلب أسعار جميع المركبات
  Stream<List<VehiclePricing>> getVehiclePricings() {
    return _firestore
        .collection(AppConfig.vehiclesCollection)
        .snapshots()
        .map((s) =>
            s.docs.map((d) => VehiclePricing.fromMap(d.data(), d.id)).toList());
  }

  /// تهيئة أسعار المركبات الافتراضية (تُستدعى مرة واحدة)
  Future<void> initializeDefaultPricings() async {
    for (final v in AppConstants.vehicleTypes) {
      final doc =
          await _firestore.collection(AppConfig.vehiclesCollection).doc(v['id']).get();
      if (!doc.exists) {
        await _firestore
            .collection(AppConfig.vehiclesCollection)
            .doc(v['id'])
            .set({
          'name_ar': v['name_ar'],
          'name_en': v['name_en'],
          'price_per_km': v['default_price_per_km'],
          'max_weight_kg': v['max_weight_kg'],
          'is_active': true,
        });
      }
    }
  }

  /// جميع الطلبات
  Stream<List<OrderModel>> getAllOrders() {
    return _firestore
        .collection(AppConfig.ordersCollection)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((s) => s.docs.map((d) => OrderModel.fromMap(d.data(), d.id)).toList());
  }

  /// إحصائيات لوحة الأدمن
  Future<Map<String, dynamic>> getDashboardStats() async {
    final usersSnap = await _firestore.collection(AppConfig.usersCollection).get();
    final ordersSnap = await _firestore.collection(AppConfig.ordersCollection).get();

    int customers = 0, drivers = 0, blocked = 0;
    for (final doc in usersSnap.docs) {
      final role = doc.data()['role'];
      if (role == 'customer') customers++;
      if (role == 'driver') drivers++;
      if (doc.data()['isBlocked'] == true) blocked++;
    }

    int pending = 0, delivered = 0, cancelled = 0;
    double totalRevenue = 0;
    for (final doc in ordersSnap.docs) {
      final status = doc.data()['status'];
      if (status == 'pending') pending++;
      if (status == 'delivered') {
        delivered++;
        totalRevenue += (doc.data()['totalPrice'] as num?)?.toDouble() ?? 0;
      }
      if (status == 'cancelled') cancelled++;
    }

    return {
      'totalUsers': usersSnap.size,
      'customers': customers,
      'drivers': drivers,
      'blocked': blocked,
      'totalOrders': ordersSnap.size,
      'pendingOrders': pending,
      'deliveredOrders': delivered,
      'cancelledOrders': cancelled,
      'totalRevenue': totalRevenue,
    };
  }
}
