import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uuid/uuid.dart';
import 'package:latlong2/latlong.dart';
import '../models/order_model.dart';
import '../config/app_config.dart';
import '../core/services/osrm_service.dart';

/// مزود الطلبات - إنشاء الطلبات، تتبعها، وإدارة حالتها
class OrderProvider extends ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  List<OrderModel> _myOrders = [];
  OrderModel? _activeOrder;
  bool _isLoading = false;

  List<OrderModel> get myOrders => _myOrders;
  OrderModel? get activeOrder => _activeOrder;
  bool get isLoading => _isLoading;

  /// إنشاء طلب جديد
  Future<OrderModel?> createOrder({
    required String customerId,
    required String customerName,
    required String customerPhone,
    required String vehicleType,
    required String vehicleNameAr,
    required LatLng pickup,
    required String pickupAddress,
    required LatLng destination,
    required String destinationAddress,
    required double pricePerKm,
    String? notes,
  }) async {
    _isLoading = true;
    notifyListeners();

    try {
      // حساب المسافة والمسار عبر OSRM
      final routeData = await OSRMService.getRoute(
        start: pickup,
        end: destination,
      );

      double distanceKm =
          routeData?['distance'] ?? OSRMService.calculateDistance(pickup, destination);
      List<List<double>>? routeCoords =
          (routeData?['coordinates'] as List?)
              ?.map<List<double>>((e) => List<double>.from(e as List))
              .toList();

      if (distanceKm < AppConfig.minimumDistanceKm) {
        distanceKm = AppConfig.minimumDistanceKm;
      }

      final totalPrice = distanceKm * pricePerKm;
      final orderId = const Uuid().v4();

      final order = OrderModel(
        id: orderId,
        customerId: customerId,
        customerName: customerName,
        customerPhone: customerPhone,
        vehicleType: vehicleType,
        vehicleNameAr: vehicleNameAr,
        pickupLat: pickup.latitude,
        pickupLng: pickup.longitude,
        pickupAddress: pickupAddress,
        destinationLat: destination.latitude,
        destinationLng: destination.longitude,
        destinationAddress: destinationAddress,
        distanceKm: distanceKm,
        pricePerKm: pricePerKm,
        totalPrice: totalPrice,
        status: 'pending',
        notes: notes,
        routeCoordinates: routeCoords,
        createdAt: DateTime.now(),
      );

      await _firestore
          .collection(AppConfig.ordersCollection)
          .doc(orderId)
          .set(order.toMap());

      _activeOrder = order;
      _isLoading = false;
      notifyListeners();
      return order;
    } catch (e) {
      _isLoading = false;
      notifyListeners();
      return null;
    }
  }

  /// قبول السائق للطلب - الأول يحجز
  Future<bool> acceptOrderByDriver({
    required String orderId,
    required String driverId,
    required String driverName,
    required String driverPhone,
  }) async {
    try {
      final ref = _firestore.collection(AppConfig.ordersCollection).doc(orderId);
      return await _firestore.runTransaction<bool>((tx) async {
        final snap = await tx.get(ref);
        if (!snap.exists) return false;
        final current = snap.data() as Map<String, dynamic>;
        if (current['status'] != 'pending') return false; // محجوز مسبقاً
        tx.update(ref, {
          'driverId': driverId,
          'driverName': driverName,
          'driverPhone': driverPhone,
          'status': 'accepted',
          'acceptedAt': FieldValue.serverTimestamp(),
        });
        return true;
      });
    } catch (_) {
      return false;
    }
  }

  /// تحديث حالة الطلب
  Future<void> updateOrderStatus(String orderId, String newStatus) async {
    final data = {'status': newStatus};
    if (newStatus == 'picked_up') {
      data['pickedUpAt'] = FieldValue.serverTimestamp() as dynamic;
    } else if (newStatus == 'delivered') {
      data['deliveredAt'] = FieldValue.serverTimestamp() as dynamic;
    } else if (newStatus == 'cancelled') {
      data['cancelledAt'] = FieldValue.serverTimestamp() as dynamic;
    }
    await _firestore
        .collection(AppConfig.ordersCollection)
        .doc(orderId)
        .update(data);
  }

  /// إلغاء الطلب
  Future<void> cancelOrder(String orderId, String reason) async {
    await _firestore.collection(AppConfig.ordersCollection).doc(orderId).update({
      'status': 'cancelled',
      'cancelReason': reason,
      'cancelledAt': FieldValue.serverTimestamp(),
    });
  }

  /// تقييم السائق بعد التسليم
  Future<void> rateOrder({
    required String orderId,
    required String driverId,
    required double rating,
    String? review,
  }) async {
    await _firestore
        .collection(AppConfig.ordersCollection)
        .doc(orderId)
        .update({
      'customerRating': rating,
      'customerReview': review,
    });

    // تحديث متوسط تقييم السائق
    final driverRef =
        _firestore.collection(AppConfig.usersCollection).doc(driverId);
    await _firestore.runTransaction((tx) async {
      final snap = await tx.get(driverRef);
      if (!snap.exists) return;
      final data = snap.data() as Map<String, dynamic>;
      final currentRating = (data['rating'] as num?)?.toDouble() ?? 0.0;
      final totalRatings = (data['totalRatings'] as int?) ?? 0;
      final newTotal = totalRatings + 1;
      final newRating = ((currentRating * totalRatings) + rating) / newTotal;
      tx.update(driverRef, {
        'rating': newRating,
        'totalRatings': newTotal,
      });
    });
  }

  /// تدفق طلبات المستخدم
  Stream<List<OrderModel>> getCustomerOrders(String customerId) {
    return _firestore
        .collection(AppConfig.ordersCollection)
        .where('customerId', isEqualTo: customerId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((s) => s.docs.map((d) => OrderModel.fromMap(d.data(), d.id)).toList());
  }

  /// تدفق طلبات السائق
  Stream<List<OrderModel>> getDriverOrders(String driverId) {
    return _firestore
        .collection(AppConfig.ordersCollection)
        .where('driverId', isEqualTo: driverId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((s) => s.docs.map((d) => OrderModel.fromMap(d.data(), d.id)).toList());
  }

  /// تدفق طلب واحد للتتبع
  Stream<OrderModel?> watchOrder(String orderId) {
    return _firestore
        .collection(AppConfig.ordersCollection)
        .doc(orderId)
        .snapshots()
        .map((s) => s.exists ? OrderModel.fromMap(s.data()!, s.id) : null);
  }
}
