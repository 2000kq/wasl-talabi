import 'package:cloud_firestore/cloud_firestore.dart';

/// نموذج بيانات المستخدم
class UserModel {
  final String uid;
  final String name;
  final String email;
  final String phone;
  final String role; // customer | driver | admin
  final String? photoUrl;
  final bool isBlocked;
  final bool isAvailable; // للسائقين فقط
  final String? vehicleType; // للسائقين
  final String? vehiclePlate;
  final double? currentLat;
  final double? currentLng;
  final double rating;
  final int totalRatings;
  final double totalEarnings;
  final int totalOrders;
  final DateTime createdAt;
  final DateTime? lastSeen;
  final String? fcmToken;
  final String? telegramChatId;

  UserModel({
    required this.uid,
    required this.name,
    required this.email,
    required this.phone,
    required this.role,
    this.photoUrl,
    this.isBlocked = false,
    this.isAvailable = false,
    this.vehicleType,
    this.vehiclePlate,
    this.currentLat,
    this.currentLng,
    this.rating = 0.0,
    this.totalRatings = 0,
    this.totalEarnings = 0.0,
    this.totalOrders = 0,
    required this.createdAt,
    this.lastSeen,
    this.fcmToken,
    this.telegramChatId,
  });

  factory UserModel.fromMap(Map<String, dynamic> map, String docId) {
    return UserModel(
      uid: docId,
      name: map['name'] ?? '',
      email: map['email'] ?? '',
      phone: map['phone'] ?? '',
      role: map['role'] ?? 'customer',
      photoUrl: map['photoUrl'],
      isBlocked: map['isBlocked'] ?? false,
      isAvailable: map['isAvailable'] ?? false,
      vehicleType: map['vehicleType'],
      vehiclePlate: map['vehiclePlate'],
      currentLat: (map['currentLat'] as num?)?.toDouble(),
      currentLng: (map['currentLng'] as num?)?.toDouble(),
      rating: (map['rating'] as num?)?.toDouble() ?? 0.0,
      totalRatings: map['totalRatings'] ?? 0,
      totalEarnings: (map['totalEarnings'] as num?)?.toDouble() ?? 0.0,
      totalOrders: map['totalOrders'] ?? 0,
      createdAt: (map['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      lastSeen: (map['lastSeen'] as Timestamp?)?.toDate(),
      fcmToken: map['fcmToken'],
      telegramChatId: map['telegramChatId'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'email': email,
      'phone': phone,
      'role': role,
      'photoUrl': photoUrl,
      'isBlocked': isBlocked,
      'isAvailable': isAvailable,
      'vehicleType': vehicleType,
      'vehiclePlate': vehiclePlate,
      'currentLat': currentLat,
      'currentLng': currentLng,
      'rating': rating,
      'totalRatings': totalRatings,
      'totalEarnings': totalEarnings,
      'totalOrders': totalOrders,
      'createdAt': Timestamp.fromDate(createdAt),
      'lastSeen': lastSeen != null ? Timestamp.fromDate(lastSeen!) : null,
      'fcmToken': fcmToken,
      'telegramChatId': telegramChatId,
    };
  }

  bool get isAdmin => role == 'admin';
  bool get isDriver => role == 'driver';
  bool get isCustomer => role == 'customer';

  UserModel copyWith({
    String? name,
    String? phone,
    String? role,
    String? photoUrl,
    bool? isBlocked,
    bool? isAvailable,
    String? vehicleType,
    String? vehiclePlate,
    double? currentLat,
    double? currentLng,
    double? rating,
    int? totalRatings,
    double? totalEarnings,
    int? totalOrders,
    String? fcmToken,
    String? telegramChatId,
  }) {
    return UserModel(
      uid: uid,
      name: name ?? this.name,
      email: email,
      phone: phone ?? this.phone,
      role: role ?? this.role,
      photoUrl: photoUrl ?? this.photoUrl,
      isBlocked: isBlocked ?? this.isBlocked,
      isAvailable: isAvailable ?? this.isAvailable,
      vehicleType: vehicleType ?? this.vehicleType,
      vehiclePlate: vehiclePlate ?? this.vehiclePlate,
      currentLat: currentLat ?? this.currentLat,
      currentLng: currentLng ?? this.currentLng,
      rating: rating ?? this.rating,
      totalRatings: totalRatings ?? this.totalRatings,
      totalEarnings: totalEarnings ?? this.totalEarnings,
      totalOrders: totalOrders ?? this.totalOrders,
      createdAt: createdAt,
      lastSeen: lastSeen,
      fcmToken: fcmToken ?? this.fcmToken,
      telegramChatId: telegramChatId ?? this.telegramChatId,
    );
  }
}
