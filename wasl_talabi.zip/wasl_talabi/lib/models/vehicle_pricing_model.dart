class VehiclePricing {
  final String id;
  final String nameAr;
  final String nameEn;
  final double pricePerKm;
  final int maxWeightKg;
  final bool isActive;

  VehiclePricing({
    required this.id,
    required this.nameAr,
    required this.nameEn,
    required this.pricePerKm,
    required this.maxWeightKg,
    this.isActive = true,
  });

  factory VehiclePricing.fromMap(Map<String, dynamic> map, String docId) {
    return VehiclePricing(
      id: docId,
      nameAr: map['name_ar'] ?? '',
      nameEn: map['name_en'] ?? '',
      pricePerKm: (map['price_per_km'] as num?)?.toDouble() ?? 0.0,
      maxWeightKg: map['max_weight_kg'] ?? 0,
      isActive: map['is_active'] ?? true,
    );
  }

  Map<String, dynamic> toMap() => {
        'name_ar': nameAr,
        'name_en': nameEn,
        'price_per_km': pricePerKm,
        'max_weight_kg': maxWeightKg,
        'is_active': isActive,
      };
}
