import 'package:cloud_firestore/cloud_firestore.dart';

/// نموذج بيانات الطلب
class OrderModel {
  final String id;
  final String customerId;
  final String customerName;
  final String customerPhone;
  final String? driverId;
  final String? driverName;
  final String? driverPhone;
  final String vehicleType;
  final String vehicleNameAr;
  final double pickupLat;
  final double pickupLng;
  final String pickupAddress;
  final double destinationLat;
  final double destinationLng;
  final String destinationAddress;
  final double distanceKm;
  final double pricePerKm;
  final double totalPrice;
  final String status; // pending|accepted|picked_up|in_transit|delivered|cancelled
  final String? notes;
  final List<List<double>>? routeCoordinates;
  final DateTime createdAt;
  final DateTime? acceptedAt;
  final DateTime? pickedUpAt;
  final DateTime? deliveredAt;
  final DateTime? cancelledAt;
  final String? cancelReason;
  final double? customerRating;
  final String? customerReview;

  OrderModel({
    required this.id,
    required this.customerId,
    required this.customerName,
    required this.customerPhone,
    this.driverId,
    this.driverName,
    this.driverPhone,
    required this.vehicleType,
    required this.vehicleNameAr,
    required this.pickupLat,
    required this.pickupLng,
    required this.pickupAddress,
    required this.destinationLat,
    required this.destinationLng,
    required this.destinationAddress,
    required this.distanceKm,
    required this.pricePerKm,
    required this.totalPrice,
    required this.status,
    this.notes,
    this.routeCoordinates,
    required this.createdAt,
    this.acceptedAt,
    this.pickedUpAt,
    this.deliveredAt,
    this.cancelledAt,
    this.cancelReason,
    this.customerRating,
    this.customerReview,
  });

  factory OrderModel.fromMap(Map<String, dynamic> map, String docId) {
    List<List<double>>? coords;
    if (map['routeCoordinates'] != null) {
      coords = (map['routeCoordinates'] as List)
          .map((e) => List<double>.from(e as List))
          .toList();
    }
    return OrderModel(
      id: docId,
      customerId: map['customerId'] ?? '',
      customerName: map['customerName'] ?? '',
      customerPhone: map['customerPhone'] ?? '',
      driverId: map['driverId'],
      driverName: map['driverName'],
      driverPhone: map['driverPhone'],
      vehicleType: map['vehicleType'] ?? '',
      vehicleNameAr: map['vehicleNameAr'] ?? '',
      pickupLat: (map['pickupLat'] as num).toDouble(),
      pickupLng: (map['pickupLng'] as num).toDouble(),
      pickupAddress: map['pickupAddress'] ?? '',
      destinationLat: (map['destinationLat'] as num).toDouble(),
      destinationLng: (map['destinationLng'] as num).toDouble(),
      destinationAddress: map['destinationAddress'] ?? '',
      distanceKm: (map['distanceKm'] as num).toDouble(),
      pricePerKm: (map['pricePerKm'] as num).toDouble(),
      totalPrice: (map['totalPrice'] as num).toDouble(),
      status: map['status'] ?? 'pending',
      notes: map['notes'],
      routeCoordinates: coords,
      createdAt: (map['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      acceptedAt: (map['acceptedAt'] as Timestamp?)?.toDate(),
      pickedUpAt: (map['pickedUpAt'] as Timestamp?)?.toDate(),
      deliveredAt: (map['deliveredAt'] as Timestamp?)?.toDate(),
      cancelledAt: (map['cancelledAt'] as Timestamp?)?.toDate(),
      cancelReason: map['cancelReason'],
      customerRating: (map['customerRating'] as num?)?.toDouble(),
      customerReview: map['customerReview'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'customerId': customerId,
      'customerName': customerName,
      'customerPhone': customerPhone,
      'driverId': driverId,
      'driverName': driverName,
      'driverPhone': driverPhone,
      'vehicleType': vehicleType,
      'vehicleNameAr': vehicleNameAr,
      'pickupLat': pickupLat,
      'pickupLng': pickupLng,
      'pickupAddress': pickupAddress,
      'destinationLat': destinationLat,
      'destinationLng': destinationLng,
      'destinationAddress': destinationAddress,
      'distanceKm': distanceKm,
      'pricePerKm': pricePerKm,
      'totalPrice': totalPrice,
      'status': status,
      'notes': notes,
      'routeCoordinates': routeCoordinates,
      'createdAt': Timestamp.fromDate(createdAt),
      'acceptedAt':
          acceptedAt != null ? Timestamp.fromDate(acceptedAt!) : null,
      'pickedUpAt':
          pickedUpAt != null ? Timestamp.fromDate(pickedUpAt!) : null,
      'deliveredAt':
          deliveredAt != null ? Timestamp.fromDate(deliveredAt!) : null,
      'cancelledAt':
          cancelledAt != null ? Timestamp.fromDate(cancelledAt!) : null,
      'cancelReason': cancelReason,
      'customerRating': customerRating,
      'customerReview': customerReview,
    };
  }
}
