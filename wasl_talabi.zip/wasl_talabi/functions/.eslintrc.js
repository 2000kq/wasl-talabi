module.exports = {
  env: { es6: true, node: true },
  parserOptions: { ecmaVersion: 2020 },
  extends: ["eslint:recommended"],
  rules: { quotes: ["off"], "no-unused-vars": "warn" },
};
