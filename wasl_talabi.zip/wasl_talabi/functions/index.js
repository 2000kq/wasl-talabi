/**
 * Cloud Functions لتطبيق وصل طلبي
 * ⚠️ توكن Telegram يبقى هنا فقط - لا يُكشف للعميل أبداً
 */
const functions = require("firebase-functions");
const admin = require("firebase-admin");
const fetch = require("node-fetch");

admin.initializeApp();

// ============ إعدادات Telegram Bot ============
// ضع توكن البوت في متغيرات البيئة:
//   firebase functions:config:set telegram.token="YOUR_BOT_TOKEN"
//   firebase functions:config:set telegram.username="YOUR_BOT_USERNAME"
const TELEGRAM_BOT_TOKEN =
  functions.config().telegram?.token || process.env.TELEGRAM_BOT_TOKEN || "";
const TELEGRAM_BOT_USERNAME =
  functions.config().telegram?.username || "WaslTalabi_Bot";

/**
 * استقبال طلب استعادة كلمة المرور وإرسال رابط عبر Telegram
 */
exports.sendPasswordResetTelegram = functions.https.onRequest(
  async (req, res) => {
    // CORS
    res.set("Access-Control-Allow-Origin", "*");
    res.set("Access-Control-Allow-Methods", "POST, OPTIONS");
    res.set("Access-Control-Allow-Headers", "Content-Type");
    if (req.method === "OPTIONS") return res.status(204).send("");

    try {
      const { email, telegramUsername } = req.body || {};
      if (!email) {
        return res.status(400).json({ error: "email مطلوب" });
      }

      // البحث عن المستخدم
      const userRecord = await admin.auth().getUserByEmail(email);

      // إنشاء رابط إعادة تعيين كلمة المرور
      const resetLink = await admin.auth().generatePasswordResetLink(email);

      // البحث عن chat_id المرتبط بالمستخدم في Firestore
      const userDoc = await admin
        .firestore()
        .collection("users")
        .doc(userRecord.uid)
        .get();
      const chatId = userDoc.data()?.telegramChatId;

      if (!chatId) {
        return res.status(404).json({
          error:
            "هذا المستخدم لم يربط حساب Telegram. افتح البوت أولاً: t.me/" +
            TELEGRAM_BOT_USERNAME,
        });
      }

      // إرسال الرسالة عبر Telegram Bot API
      const message =
        `🔐 طلب إعادة تعيين كلمة المرور لـ وصل طلبي\n\n` +
        `للمتابعة اضغط على الرابط:\n${resetLink}\n\n` +
        `إذا لم تطلب ذلك تجاهل الرسالة.`;

      const tgResp = await fetch(
        `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ chat_id: chatId, text: message }),
        }
      );
      const tgData = await tgResp.json();
      if (!tgData.ok) {
        return res.status(500).json({ error: "فشل إرسال رسالة Telegram" });
      }

      return res.status(200).json({ success: true });
    } catch (err) {
      console.error(err);
      return res.status(500).json({ error: err.message });
    }
  }
);

/**
 * Webhook لاستقبال رسائل البوت
 * عند إرسال المستخدم /start <uid> يتم ربط chat_id بالحساب
 */
exports.telegramWebhook = functions.https.onRequest(async (req, res) => {
  try {
    const update = req.body;
    if (!update.message) return res.status(200).send("OK");

    const chatId = update.message.chat.id;
    const text = update.message.text || "";

    if (text.startsWith("/start")) {
      const parts = text.split(" ");
      const uid = parts[1];
      if (uid) {
        await admin
          .firestore()
          .collection("users")
          .doc(uid)
          .update({ telegramChatId: chatId });
        await fetch(
          `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              chat_id: chatId,
              text:
                "✅ تم ربط حسابك بنجاح بـ وصل طلبي.\n" +
                "يمكنك الآن استعادة كلمة المرور عبر هذا البوت.",
            }),
          }
        );
      }
    }
    return res.status(200).send("OK");
  } catch (err) {
    console.error(err);
    return res.status(500).send("ERROR");
  }
});

/**
 * إشعارات السائقين القريبين بالطلبات الجديدة
 */
exports.notifyNearbyDrivers = functions.firestore
  .document("orders/{orderId}")
  .onCreate(async (snap, ctx) => {
    const order = snap.data();
    if (order.status !== "pending") return null;

    // جلب السائقين المتاحين بنوع المركبة المطلوب
    const drivers = await admin
      .firestore()
      .collection("users")
      .where("role", "==", "driver")
      .where("isAvailable", "==", true)
      .where("vehicleType", "==", order.vehicleType)
      .get();

    const tokens = drivers.docs
      .map((d) => d.data().fcmToken)
      .filter(Boolean);

    if (tokens.length === 0) return null;

    return admin.messaging().sendEachForMulticast({
      tokens,
      notification: {
        title: "🚚 طلب جديد بالقرب منك",
        body: `${order.vehicleNameAr} - ${order.totalPrice} د.ع`,
      },
      data: { orderId: ctx.params.orderId },
    });
  });
