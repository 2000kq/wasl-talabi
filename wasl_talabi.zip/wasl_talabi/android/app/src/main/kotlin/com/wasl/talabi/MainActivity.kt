package com.wasl.talabi

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
