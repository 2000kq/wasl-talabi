# 🏗️ دليل بناء APK لتطبيق وصل طلبي

## 📋 المتطلبات الأساسية

| الأداة | الإصدار | رابط التحميل |
|--------|---------|-------------|
| Flutter SDK | ≥ 3.10.0 | https://flutter.dev/docs/get-started/install |
| Android Studio | الأحدث | https://developer.android.com/studio |
| JDK | 17 | https://www.oracle.com/java/technologies/downloads/ |
| Git | ≥ 2.30 | https://git-scm.com/ |

## 🚀 خطوات البناء

### الخطوة 1: استخراج الملف وفتحه
```bash
unzip wasl_talabi.zip
cd wasl_talabi
```

### الخطوة 2: التحقق من بيئة Flutter
```bash
flutter doctor -v
```
> تأكد أن جميع المكونات لـ Android خضراء ✅

### الخطوة 3: تثبيت تبعيات Flutter
```bash
flutter pub get
```

### الخطوة 4: إضافة الخطوط (Cairo)
حمّل خط Cairo من Google Fonts وضعه في:
```
assets/fonts/Cairo-Regular.ttf
assets/fonts/Cairo-Bold.ttf
```
الرابط: https://fonts.google.com/specimen/Cairo

> إذا لم تضع الخطوط، سيستخدم التطبيق الخط الافتراضي تلقائياً (احذف قسم `fonts` من `pubspec.yaml`).

### الخطوة 5: تجربة التطبيق على المحاكي
```bash
flutter run
```

### الخطوة 6: بناء APK للإصدار (Debug)
```bash
flutter build apk --debug
```
المخرج: `build/app/outputs/flutter-apk/app-debug.apk`

### الخطوة 7: بناء APK للإنتاج (Release)
```bash
flutter build apk --release
```
المخرج: `build/app/outputs/flutter-apk/app-release.apk`

### الخطوة 8 (اختياري): بناء APK لمعالجات محددة
```bash
flutter build apk --split-per-abi --release
```
يُنتج 3 ملفات APK أصغر حجماً.

### الخطوة 9 (اختياري): بناء AAB لـ Google Play
```bash
flutter build appbundle --release
```

## 🔐 توقيع APK للإنتاج

### إنشاء مفتاح توقيع
```bash
keytool -genkey -v -keystore ~/wasl-talabi-key.jks \
  -keyalg RSA -keysize 2048 -validity 10000 -alias wasltalabi
```

### إضافة المفتاح للمشروع
أنشئ ملف `android/key.properties`:
```properties
storePassword=YOUR_PASSWORD
keyPassword=YOUR_PASSWORD
keyAlias=wasltalabi
storeFile=/path/to/wasl-talabi-key.jks
```

عدّل `android/app/build.gradle` وأضف قبل `android {`:
```gradle
def keystoreProperties = new Properties()
def keystorePropertiesFile = rootProject.file('key.properties')
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
}
```

داخل `android { buildTypes { release {` بدّل `signingConfig signingConfigs.debug` إلى:
```gradle
signingConfig signingConfigs.release
```

وأضف قسم `signingConfigs` قبل `buildTypes`:
```gradle
signingConfigs {
    release {
        keyAlias keystoreProperties['keyAlias']
        keyPassword keystoreProperties['keyPassword']
        storeFile keystoreProperties['storeFile'] ? file(keystoreProperties['storeFile']) : null
        storePassword keystoreProperties['storePassword']
    }
}
```

## ☁️ نشر Cloud Functions

```bash
cd functions
npm install
firebase login
firebase use wasltalabi
firebase functions:config:set telegram.token="YOUR_BOT_TOKEN"
firebase deploy --only functions
firebase deploy --only firestore:rules
firebase deploy --only storage:rules
firebase deploy --only firestore:indexes
```

## 🐞 حل المشاكل الشائعة

### `error: package com.google.firebase does not exist`
شغّل: `flutter clean && flutter pub get`

### `Execution failed for task ':app:processDebugGoogleServices'`
تأكد أن `android/app/google-services.json` موجود وأن `package_name` فيه = `com.wasl.talabi`.

### `MissingPluginException`
أعد بناء التطبيق: `flutter clean && flutter run`

### الخريطة لا تظهر
تأكد أن لديك اتصال إنترنت — OpenStreetMap يحتاج تحميل البلاطات أول مرة.

### الموقع لا يعمل
امنح إذن الموقع من إعدادات الجهاز يدوياً للتطبيق.

## 📲 تثبيت APK على جهاز Android

1. انقل ملف `app-release.apk` إلى الجهاز.
2. فعّل "تثبيت من مصادر غير معروفة" في الإعدادات.
3. افتح الملف واتبع التعليمات.

## ⚙️ ملاحظات هامة

- 🔥 **Firebase**: المشروع مهيأ مسبقاً لـ `wasltalabi`. لاستخدام مشروعك الخاص، استبدل:
  - `android/app/google-services.json`
  - القيم في `lib/config/firebase_options.dart`
  - القيم في `lib/config/app_config.dart`

- 📲 **Telegram Bot**: غير الافتراضيات في `lib/config/app_config.dart` وأنشئ Cloud Function.

- 👨‍💼 **حساب الأدمن**: يُنشأ تلقائياً عند أول دخول بـ `admin@wasltalabi.com`/`Wasl@Admin2025!`. غيّر كلمة المرور بعد ذلك.
