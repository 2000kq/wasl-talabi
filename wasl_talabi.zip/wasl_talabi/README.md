# 🚚 وصل طلبي (Wasl Talabi)

منصة توصيل لوجستية متكاملة لنقل البضائع باستخدام المركبات الصغيرة - Flutter + Firebase + OpenStreetMap.

## ✨ المميزات

- 🔐 **3 أدوار**: عميل، سائق، مدير
- 🗺️ **OpenStreetMap + OSRM** (بدون Google Maps)
- 📍 **تتبع GPS لحظي** للسائق
- 💬 **دردشة لحظية** بين العميل والسائق
- ⭐ **نظام تقييم** السائقين
- 📡 **تخزين المسار محلياً** (Offline)
- 🌐 **عربي/إنجليزي** RTL + LTR
- 🔔 **إشعارات FCM** للطلبات الجديدة
- 🛡️ **Telegram Bot** لاستعادة كلمة المرور (آمن عبر Cloud Functions)

## 📱 أنواع المركبات

ستوتة • توك توك • بيك آب • حمل 1/3/5 طن

## 🚀 البدء السريع

### 1. متطلبات النظام
- Flutter SDK 3.10+
- Android Studio / VS Code
- حساب Firebase
- JDK 17

### 2. تثبيت التبعيات
```bash
cd wasl_talabi
flutter pub get
```

### 3. تكوين Firebase
المشروع مهيأ مسبقاً للاتصال بـ `wasltalabi` Firebase Project:
- `android/app/google-services.json` ✅ موجود
- `lib/config/firebase_options.dart` ✅ مهيأ

### 4. تشغيل التطبيق
```bash
flutter run
```

### 5. بناء APK للإنتاج
```bash
flutter build apk --release
```
الـ APK يُنشأ في: `build/app/outputs/flutter-apk/app-release.apk`

## 👤 حساب الأدمن الافتراضي
```
البريد:    admin@wasltalabi.com
كلمة المرور: Wasl@Admin2025!
```
> سيتم إنشاء الحساب تلقائياً عند أول تسجيل دخول.

## 🔧 إعداد Cloud Functions (Telegram)

```bash
cd functions
npm install
firebase functions:config:set telegram.token="YOUR_BOT_TOKEN_FROM_BOTFATHER"
firebase functions:config:set telegram.username="YOUR_BOT_USERNAME"
firebase deploy --only functions
```

### إعداد Telegram Webhook
```bash
curl "https://api.telegram.org/bot<TOKEN>/setWebhook?url=https://us-central1-wasltalabi.cloudfunctions.net/telegramWebhook"
```

## 📦 هيكل المشروع

```
lib/
├── config/           # إعدادات Firebase والتطبيق
├── core/
│   ├── constants/    # ثوابت + أنواع المركبات
│   ├── services/     # OSRM, Location, FCM, Telegram
│   └── theme/        # الألوان والثيم
├── localization/     # نظام الترجمة
├── models/           # نماذج البيانات
├── providers/        # State Management (Provider)
├── routes/           # مسارات التطبيق
├── screens/
│   ├── auth/         # تسجيل/دخول/استعادة
│   ├── customer/     # شاشات العميل
│   ├── driver/       # شاشات السائق
│   ├── admin/        # لوحة الأدمن
│   └── shared/       # دردشة، إعدادات
└── widgets/          # عناصر واجهة قابلة لإعادة الاستخدام
```

## 🛡️ الأمان

- ✅ قواعد Firestore تمنع الوصول غير المصرح به
- ✅ Telegram Bot Token محفوظ في Cloud Functions فقط
- ⚠️ في الإنتاج: استخدم App Check + قم بتدوير API keys

## 📄 الترخيص
MIT - استخدمه بحرية للمشاريع الشخصية والتجارية.
