import 'package:flutter_test/flutter_test.dart';

void main() {
  test('Wasl Talabi smoke test', () {
    // اختبار بسيط لضمان نجاح بناء المشروع
    expect(1 + 1, 2);
  });
}
